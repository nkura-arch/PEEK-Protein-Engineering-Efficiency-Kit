// V11 presentation only. Does not change requests, scientific results or storage.
document.addEventListener('DOMContentLoaded', function () {
  const dna = document.querySelector('textarea[name="dna"]');
  const preview = document.getElementById('liveSequence');
  if (!dna || !preview) return;
  const position = document.querySelector('[name="cut_pos"], [name="pos"]');
  function renderPreview() {
    const raw = dna.value.replace(/\s/g, '').toUpperCase();
    const valid = /^[ATCG]*$/.test(raw);
    const point = Number(position ? position.value : 0);
    const hasPoint = Number.isInteger(point) && point > 0 && point <= raw.length;
    const start = hasPoint ? Math.max(0, Math.min(point - 13, raw.length - 36)) : 0;
    const snippet = raw.slice(start, start + 36);
    document.getElementById('previewLength').textContent = raw.length.toLocaleString();
    document.getElementById('previewGC').textContent = valid && raw.length ? Math.round((raw.match(/[GC]/g) || []).length / raw.length * 100) + '%' : '—';
    document.getElementById('previewRange').textContent = raw.length ? 'BASES ' + (start + 1) + '–' + (start + snippet.length) : 'ADD A SEQUENCE TO BEGIN';
    document.getElementById('previewPosition').textContent = hasPoint ? 'Base ' + point.toLocaleString() : 'No valid position selected';
    preview.replaceChildren();
    for (let i = 0; i < snippet.length; i++) {
      const base = document.createElement('span');
      base.className = 'preview-base' + (hasPoint && start + i + 1 === point ? ' is-target' : '');
      base.dataset.base = snippet[i];
      base.textContent = snippet[i];
      base.title = 'Base ' + (start + i + 1);
      preview.appendChild(base);
    }
  }
  document.addEventListener('input', renderPreview);
  document.addEventListener('change', renderPreview);
  // Existing example/clear handlers set values synchronously before this listener.
  document.addEventListener('click', function (event) {
    if (event.target.closest('button')) requestAnimationFrame(renderPreview);
  });
  renderPreview();
});
