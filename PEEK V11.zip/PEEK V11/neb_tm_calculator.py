"""
NEB Tm & Ta calculator for Q5 High-Fidelity Polymerase.

Implements the SantaLucia (1998) unified nearest-neighbor thermodynamic model
for the base Tm, then the Owczarzy (2008) multi-ion correction to account for
the Q5 Reaction Buffer's monovalent + Mg2+ + dNTP composition.
"""

import math

# ---------- Physical constants ----------
R = 1.987            # cal / (K * mol)
KELVIN_OFFSET = 273.15

# ---------- Q5 Reaction Buffer defaults ----------
DEFAULT_PRIMER_CONC = 5e-7    # M (0.5 uM)
DEFAULT_MON = 0.050           # M monovalent cations (50 mM)
DEFAULT_MG = 0.002            # M Mg2+ (2.0 mM)
DEFAULT_DNTP = 0.0008         # M total dNTPs (0.8 mM)

# ---------- Unified SantaLucia (1998) nearest-neighbor table ----------
# Each entry: (delta_H in cal/mol, delta_S in cal/(K*mol))
_NN_PARAMS = {
    "AA": (-7900, -22.2), "TT": (-7900, -22.2),
    "AT": (-7200, -20.4),
    "TA": (-7200, -21.3),
    "CA": (-8500, -22.7), "TG": (-8500, -22.7),
    "GT": (-8400, -22.4), "AC": (-8400, -22.4),
    "CT": (-7800, -21.0), "AG": (-7800, -21.0),
    "GA": (-8200, -22.2), "TC": (-8200, -22.2),
    "CG": (-10600, -27.2),
    "GC": (-9800, -24.4),
    "GG": (-8000, -19.9), "CC": (-8000, -19.9),
}
_INIT_H = 2300.0
_INIT_S = 4.1

# ---------- Owczarzy (2008) seven-coefficient Mg-dominated polynomial ----------
_OWCZARZY_MG = {
    "a": 3.92e-5,
    "b": -9.11e-6,
    "c": 6.26e-5,
    "d": 1.42e-5,
    "e": -4.82e-4,
    "f": 5.25e-4,
    "g": 8.31e-5,
}


class InvalidSequenceError(ValueError):
    pass


def clean_sequence(seq):
    """Strip whitespace/flanking notation, uppercase, and validate bases."""
    cleaned = seq.strip().upper()
    cleaned = cleaned.replace("5'", "").replace("3'", "").replace("-", "")
    cleaned = "".join(cleaned.split())
    if not cleaned:
        raise InvalidSequenceError("Sequence is empty.")
    invalid = set(cleaned) - set("ATCG")
    if invalid:
        raise InvalidSequenceError(
            f"Invalid characters found: {', '.join(sorted(invalid))}. Only A, T, C, G are allowed."
        )
    return cleaned


def gc_fraction(seq):
    n = len(seq)
    if n == 0:
        return 0.0
    return (seq.count("G") + seq.count("C")) / n


def _base_tm_kelvin(seq, primer_conc):
    """SantaLucia (1998) unified NN model -> base Tm in Kelvin (1 M Na+ reference)."""
    delta_h = _INIT_H
    delta_s = _INIT_S
    for i in range(len(seq) - 1):
        step = seq[i:i + 2]
        h, s = _NN_PARAMS[step]
        delta_h += h
        delta_s += s
    return delta_h / (delta_s + R * math.log(primer_conc))


def _owczarzy_correction(tm_base_k, seq, mon, mg, dntp):
    """Owczarzy (2008) multi-ion correction. Returns corrected Tm in Kelvin."""
    n = len(seq)
    f_gc = gc_fraction(seq)

    mg_free = mg - dntp
    ratio = math.sqrt(max(mg_free, 0.0)) / mon

    inv_tm = 1.0 / tm_base_k

    if ratio < 0.22:
        m = mon
        ln_m = math.log(m)
        inv_tm_corr = (
            inv_tm
            + (4.29 * f_gc - 3.95) * 1e-5 * ln_m
            + 9.40e-6 * (ln_m ** 2)
        )
    else:
        m = mg_free
        ln_m = math.log(m)
        c = _OWCZARZY_MG
        inv_tm_corr = (
            inv_tm
            + c["a"]
            + c["b"] * ln_m
            + f_gc * (c["c"] + c["d"] * ln_m)
            + (c["e"] + c["f"] * ln_m + c["g"] * (ln_m ** 2)) / (2 * (n - 1))
        )

    return 1.0 / inv_tm_corr


def calculate_tm(sequence, primer_conc=DEFAULT_PRIMER_CONC, mon=DEFAULT_MON,
                  mg=DEFAULT_MG, dntp=DEFAULT_DNTP):
    """Calculate Q5 NEB-style Tm (deg C) for a primer sequence."""
    seq = clean_sequence(sequence)
    if len(seq) < 2:
        raise InvalidSequenceError("Sequence must be at least 2 bases long.")

    tm_base_k = _base_tm_kelvin(seq, primer_conc)
    tm_corrected_k = _owczarzy_correction(tm_base_k, seq, mon, mg, dntp)
    return tm_corrected_k - KELVIN_OFFSET


def calculate_ta(tm1, tm2, offset=1.0, ceiling=72.0):
    """
    NEB Q5 annealing temperature: Ta = min(Tm1, Tm2) + offset, capped at ceiling.
    Always returns a numeric annealing temperature (deg C).
    """
    tm_min = min(tm1, tm2)
    ta = min(tm_min + offset, ceiling)
    return round(ta, 1)
