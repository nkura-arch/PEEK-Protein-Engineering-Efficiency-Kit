PEEK V11 - Local design preview
==============================

Base: PEEK-Host, commit 616327d (V10 plus the existing hosting and UI fixes).
Repository: https://github.com/nkura-arch/PEEK-Host

V11 changes the presentation layer:
- Dark blue workspace with responsive desktop sidebar and mobile/tablet tabs.
- Updated typography, spacing, panels, controls and results styling.
- Original glowing glass DNA artwork; the single-twist favicon is retained.
- Optional restrained parallax and control feedback with a motion toggle.
  Device reduced-motion preferences are respected. No WebGL renderer is included.
- Live input-sequence context on the silent mutation and primer design tools.
- Collapsible scoring settings, accessible focus states and reduced-motion support.
- The visualizer, quick mutations, examples and saved data workflows are retained.
- Localhost previews do not send analytics events to the production dashboard.

All eight existing Python files are byte-identical to the base version.
requirements.txt and the existing static/js/main.js are also unchanged.
No formulas, design engines, ranking algorithms or backend routes were modified.

Verification:
- Four pages checked at 360, 390, 820, 1024 and 1440 pixel widths.
- Chrome, Edge, Firefox and Playwright WebKit checks passed.
- Scored mutation submission, primer design, quick enzyme transfer, visualization,
  mutation-library controls and cross-tab persistence passed in all four browsers.
- No JavaScript errors or page-level horizontal overflow in these checks.
- Ten POST response contexts matched V10 in a shared Python environment.
- Existing form names, values, constraints and request methods are unchanged.
WebKit testing approximates Safari's engine; physical iPhones/iPads were not tested.

Local use:
Install requirements.txt in a Python environment, then run python run_preview.py.
The existing launcher uses http://127.0.0.1:5000.
The separately configured preview for this computer is http://localhost:5011.

Deployment:
The existing Dockerfile, Fly configuration and deployment files are included
unchanged. This V11 preview has not been pushed to GitHub or deployed to Fly.
The production website and original PEEK-Host folder have not been modified.
