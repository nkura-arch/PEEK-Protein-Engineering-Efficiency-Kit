# Overview

PEEK (Protein Engineering Efficiency Kit) is a Flask-based web application designed for molecular biology and protein engineering workflows. The application provides tools for generating silent mutations to introduce restriction enzyme sites and designing primers for enzyme insertion or amino acid insertion. It leverages BioPython for sequence manipulation and restriction enzyme analysis, making it a specialized tool for researchers working with DNA sequences and protein engineering.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: Traditional server-rendered Flask templates with Bootstrap 5 dark theme
- **Styling**: Bootstrap CSS framework with custom CSS for molecular biology-specific UI components
- **JavaScript**: Vanilla JavaScript for client-side interactions (copy-to-clipboard, form validation, DNA sequence validation)
- **Template Engine**: Jinja2 templates with a base template providing consistent navigation and layout

## Backend Architecture
- **Framework**: Flask web framework with minimal routing structure
- **Core Logic**: BioPython-based sequence analysis and manipulation
- **Session Management**: Flask sessions with configurable secret key
- **Request Handling**: Standard Flask request/response pattern with form processing

## Key Functional Components
- **Codon Table Management**: Pre-built synonymous codon mappings using BioPython's standard genetic code
- **Restriction Enzyme Database**: Integration with BioPython's restriction enzyme collection (AllEnzymes)
- **Silent Mutation Engine**: Algorithm for generating codon-preserving mutations within specified tolerance windows
- **Primer Design Engine**: Tools for calculating melting temperatures and optimizing primer sequences for PCR

## Data Processing Pipeline
- **Sequence Validation**: DNA sequence input validation and uppercase normalization
- **Translation Services**: DNA to amino acid translation with stop codon detection
- **Window-based Analysis**: Codon-aligned sequence windows for mutation analysis
- **Enzyme Site Detection**: Pattern matching for restriction enzyme recognition sites

## Application Structure
- **Single-file Application**: Main logic consolidated in `app.py` with clear separation of concerns
- **Static Assets**: CSS and JavaScript served from static directory
- **Template Organization**: Modular HTML templates with inheritance structure

# External Dependencies

## Core Scientific Libraries
- **BioPython**: Primary dependency for sequence analysis, restriction enzymes, and genetic code tables
- **Pandas**: Data manipulation and CSV processing for results export

## Web Framework Stack
- **Flask**: Web application framework and routing
- **Bootstrap 5**: Frontend CSS framework with dark theme variant
- **Font Awesome**: Icon library for UI elements

## Development Dependencies
- **Python Standard Library**: CSV, IO, itertools for data processing
- **Environment Variables**: Session secret key configuration via environment

## Client-side Resources
- **CDN Dependencies**: Bootstrap CSS and Font Awesome served from CDNs
- **No Database**: Application operates without persistent data storage, processing sequences in memory