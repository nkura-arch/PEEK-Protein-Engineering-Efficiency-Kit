// Main JavaScript for PEEK application

// Copy to clipboard functionality
document.addEventListener('DOMContentLoaded', function() {
    // Add click handlers to copy buttons
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('copy-btn') || e.target.closest('.copy-btn')) {
            const button = e.target.classList.contains('copy-btn') ? e.target : e.target.closest('.copy-btn');
            const textToCopy = button.getAttribute('data-copy');
            
            if (textToCopy) {
                copyToClipboard(textToCopy);
                showCopySuccess(button);
            }
        }
    });

    // Form validation
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            console.log('Form submit attempt:', form.action, form.method);
            const isValid = validateForm(form);
            console.log('Form validation result:', isValid);
            
            if (!isValid) {
                console.log('Form validation failed, preventing submission');
                e.preventDefault();
                return false;
            }
            
            console.log('Form is valid, proceeding with submission');
            // Add loading state
            const submitBtn = form.querySelector('button[type="submit"]');
            if (submitBtn) {
                addLoadingState(submitBtn);
            }
        });
    });

    // DNA sequence validation
    const dnaInputs = document.querySelectorAll('textarea[name="dna"], input[name="dna"]');
    dnaInputs.forEach(input => {
        input.addEventListener('input', function(e) {
            validateDNASequence(e.target);
        });
    });

    // Auto-uppercase DNA sequences
    const sequenceInputs = document.querySelectorAll('textarea[name="dna"], textarea[name="aa_seq"]');
    sequenceInputs.forEach(input => {
        input.addEventListener('input', function(e) {
            e.target.value = e.target.value.toUpperCase();
        });
    });
});

/**
 * Copy text to clipboard
 */
async function copyToClipboard(text) {
    try {
        await navigator.clipboard.writeText(text);
        return true;
    } catch (err) {
        // Fallback for older browsers
        const textArea = document.createElement('textarea');
        textArea.value = text;
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        try {
            document.execCommand('copy');
            document.body.removeChild(textArea);
            return true;
        } catch (fallbackErr) {
            document.body.removeChild(textArea);
            return false;
        }
    }
}

/**
 * Show copy success feedback
 */
function showCopySuccess(button) {
    const originalContent = button.innerHTML;
    button.innerHTML = '<i class="fas fa-check"></i> Copied!';
    button.classList.add('btn-success');
    button.classList.remove('btn-outline-primary', 'btn-outline-light');
    
    setTimeout(() => {
        button.innerHTML = originalContent;
        button.classList.remove('btn-success');
        button.classList.add('btn-outline-primary');
    }, 2000);
}

/**
 * Validate DNA sequence
 */
function validateDNASequence(input) {
    const sequence = input.value.toUpperCase();
    const validBases = /^[ATCG]*$/;
    
    if (sequence && !validBases.test(sequence)) {
        input.setCustomValidity('DNA sequence must contain only A, T, C, G characters');
        input.classList.add('is-invalid');
        
        // Add or update error message
        let errorDiv = input.parentNode.querySelector('.invalid-feedback');
        if (!errorDiv) {
            errorDiv = document.createElement('div');
            errorDiv.className = 'invalid-feedback';
            input.parentNode.appendChild(errorDiv);
        }
        errorDiv.textContent = 'DNA sequence must contain only A, T, C, G characters';
    } else {
        input.setCustomValidity('');
        input.classList.remove('is-invalid');
        
        // Remove error message
        const errorDiv = input.parentNode.querySelector('.invalid-feedback');
        if (errorDiv) {
            errorDiv.remove();
        }
    }
}

/**
 * Validate form before submission
 */
function validateForm(form) {
    let isValid = true;
    console.log('Validating form...');
    
    // Validate required fields
    const requiredFields = form.querySelectorAll('[required]');
    console.log('Required fields:', requiredFields.length);
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            console.log('Required field empty:', field.name);
            field.classList.add('is-invalid');
            isValid = false;
        } else {
            console.log('Required field valid:', field.name, field.value.length, 'chars');
            field.classList.remove('is-invalid');
        }
    });
    
    // Validate DNA sequence
    const dnaField = form.querySelector('textarea[name="dna"]');
    if (dnaField && dnaField.value) {
        const sequence = dnaField.value.toUpperCase().replace(/\s+/g, ''); // Remove whitespace
        const validBases = /^[ATCG]*$/;
        console.log('DNA sequence length:', sequence.length, 'valid:', validBases.test(sequence));
        if (!validBases.test(sequence)) {
            dnaField.classList.add('is-invalid');
            console.log('DNA validation failed');
            isValid = false;
        } else {
            dnaField.classList.remove('is-invalid');
        }
    }
    
    // Validate amino acid sequence if present
    const aaField = form.querySelector('textarea[name="aa_seq"]');
    if (aaField && aaField.value) {
        const aaSequence = aaField.value.toUpperCase();
        const validAA = /^[ARNDCEQGHILKMFPSTWYV*]*$/;
        if (!validAA.test(aaSequence)) {
            aaField.classList.add('is-invalid');
            showError('Amino acid sequence contains invalid characters');
            isValid = false;
        }
    }
    
    console.log('Form validation complete, isValid:', isValid);
    return isValid;
}

/**
 * Add loading state to button
 */
function addLoadingState(button) {
    const originalText = button.innerHTML;
    button.innerHTML = '<span class="spinner"></span> Processing...';
    button.disabled = true;
    
    // Reset after 30 seconds max
    setTimeout(() => {
        button.innerHTML = originalText;
        button.disabled = false;
    }, 30000);
}

/**
 * Show error message
 */
function showError(message) {
    const alertDiv = document.createElement('div');
    alertDiv.className = 'alert alert-danger alert-dismissible fade show';
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    const container = document.querySelector('.container');
    if (container) {
        container.insertBefore(alertDiv, container.firstChild);
        
        // Auto-dismiss after 5 seconds
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.remove();
            }
        }, 5000);
    }
}

/**
 * Show success message
 */
function showSuccess(message) {
    const alertDiv = document.createElement('div');
    alertDiv.className = 'alert alert-success alert-dismissible fade show';
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    const container = document.querySelector('.container');
    if (container) {
        container.insertBefore(alertDiv, container.firstChild);
        
        // Auto-dismiss after 3 seconds
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.remove();
            }
        }, 3000);
    }
}

/**
 * Format sequence with spaces for better readability
 */
function formatSequence(sequence, spacer = 10) {
    return sequence.replace(new RegExp(`(.{${spacer}})`, 'g'), '$1 ').trim();
}

/**
 * Calculate basic sequence statistics
 */
function calculateSequenceStats(sequence) {
    const length = sequence.length;
    const gcCount = (sequence.match(/[GC]/g) || []).length;
    const gcContent = ((gcCount / length) * 100).toFixed(1);
    
    return {
        length: length,
        gcContent: gcContent + '%',
        atContent: (100 - gcContent).toFixed(1) + '%'
    };
}

// Export functions for use in templates
window.PEEK = {
    copyToClipboard,
    showCopySuccess,
    validateDNASequence,
    formatSequence,
    calculateSequenceStats,
    showError,
    showSuccess
};
