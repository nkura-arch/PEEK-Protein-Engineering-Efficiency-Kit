# Silent Mutation Detection Engine
# Extracted from the original bioinformatics algorithm

from Bio.Seq import Seq
from Bio.Data import CodonTable
from Bio.Restriction import CommOnly
import itertools
import csv
import pandas as pd
from codon_optimizer import CodonOptimizer


# Setup codon tables
standard_table = CodonTable.unambiguous_dna_by_name["Standard"]
SYNONYMOUS = {}
for codon, aa in standard_table.forward_table.items():
    SYNONYMOUS.setdefault(aa, []).append(codon)
CODON_TO_AA = standard_table.forward_table


def translate(seq):
    """Translate DNA sequence to amino acids"""
    return str(Seq(seq).translate())


def get_synonymous(codon):
    """Get synonymous codons for a given codon"""
    aa = CODON_TO_AA.get(codon, None)
    if not aa:
        return [codon]
    return [syn for syn in SYNONYMOUS[aa] if syn != codon]


def site_in_window(seq, enzyme, cut_pos, tolerance):
    """Check if enzyme recognition site is within tolerance of cut position"""
    rec = str(enzyme.site)
    rec_len = len(rec)
    cut_index = enzyme.fst5 if enzyme.fst5 is not None else 0
    for i in range(len(seq) - rec_len + 1):
        if seq[i:i + rec_len] == rec:
            cut_site = i + cut_index
            if abs(cut_site - cut_pos) <= tolerance:
                return cut_site
    return None


def is_valid_window(seq):
    """Check if window is valid (divisible by 3 and no stop codons)"""
    return len(seq) % 3 == 0 and "*" not in translate(seq)


def get_codon_aligned_window(dna_len, cut_pos, window_codons, coding_start_pos=0):
    """Get codon-aligned window around cut position"""
    frame_offset = coding_start_pos % 3
    
    adjusted_pos = cut_pos - frame_offset
    if adjusted_pos < 0:
        codon_start = frame_offset
    else:
        codon_start = cut_pos - (adjusted_pos % 3)
    
    half_window = window_codons // 2
    
    start = codon_start - half_window * 3
    end = codon_start + (window_codons - half_window) * 3
    
    start = max(0, start)
    end = min(dna_len, end)
    
    # Adjust start and end to maintain frame relative to coding_start_pos
    if (start - frame_offset) % 3 != 0:
        start += 3 - ((start - frame_offset) % 3)
    if (end - frame_offset) % 3 != 0:
        end -= ((end - frame_offset) % 3)
    
    return start, end, codon_start


def find_silent_sites(dna, cut_pos, tolerance, window_codons, enzymes, coding_start_pos=0, max_changes=3):
    """Find silent mutations that introduce restriction enzyme sites"""
    results = []
    start, end, codon_start = get_codon_aligned_window(len(dna), cut_pos, window_codons, coding_start_pos)
    window = dna[start:end]
    
    if not is_valid_window(window):
        return []
    
    codons = [window[i:i + 3] for i in range(0, len(window), 3)]
    codon_indices = [i for i, codon in enumerate(codons) if get_synonymous(codon)]
    orig_aa = translate(window)
    
    # Prioritize preferred enzymes for faster results
    preferred_enzymes = get_preferred_enzymes()
    preferred_set = set(preferred_enzymes)
    priority_enzymes = [e for e in enzymes if str(e) in preferred_set]
    other_enzymes = [e for e in enzymes if str(e) not in preferred_set]
    
    # Process preferred enzymes first, then others
    enzyme_list = priority_enzymes + other_enzymes
    
    # Limit search space for performance
    max_combinations = min(1000, len(enzyme_list) * 10)
    combinations_tested = 0
    
    for k in range(1, min(max_changes + 1, len(codon_indices) + 1)):
        for combo in itertools.combinations(codon_indices, k):
            if combinations_tested >= max_combinations:
                break
                
            syn_options = [get_synonymous(codons[i]) for i in combo]
            for replacements in itertools.product(*syn_options):
                if combinations_tested >= max_combinations:
                    break
                    
                combinations_tested += 1
                new_codons = codons[:]
                for idx, new_codon in zip(combo, replacements):
                    new_codons[idx] = new_codon
                mutated = ''.join(new_codons)
                if translate(mutated) != orig_aa:
                    continue
                    
                for enzyme in enzyme_list:
                    cut = site_in_window(mutated, enzyme, cut_pos - start, tolerance)
                    if cut is not None:
                        # Determine removed sequence (difference from original)
                        removed_bases = ''.join([o for o, m in zip(window, mutated) if o != m])
                        side = "5'" if mutated.find(str(enzyme.site)) < len(mutated) // 2 else "3'"
                        
                        results.append({
                            'enzyme': enzyme,
                            'new_cut': start + cut,
                            'orig_window': window,
                            'mutated': mutated,
                            'aa': translate(mutated),
                            'window_start': start,
                            'window_end': end,
                            'codon_start': codon_start,
                            'removed_bases': removed_bases,
                            'removed_side': side
                        })
                        
                        # Stop early if we found enough preferred results
                        if len(results) >= 50 and str(enzyme) in preferred_set:
                            return results
            
            if combinations_tested >= max_combinations:
                break
    
    return results


def save_results_to_csv(results, filename="silent_mutation_results.csv"):
    """Save results to CSV file"""
    with open(filename, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([
            "Result #", "Enzyme", "Recognition Site", "New Cut Position (0-based)",
            "Original Window Start", "Original Window End", "Codon Start in Window",
            "Original Window", "Mutated Window", "Amino Acids",
            "Removed Bases", "Removed Side (5'/3')"
        ])
        for i, result in enumerate(results, 1):
            writer.writerow([
                i,
                str(result['enzyme']),
                result['enzyme'].site,
                result['new_cut'],
                result['window_start'],
                result['window_end'],
                result['codon_start'],
                result['orig_window'],
                result['mutated'],
                result['aa'],
                result['removed_bases'],
                result['removed_side']
            ])
    return filename


def get_preferred_enzymes():
    """Get list of preferred enzymes"""
    return ["SalI", "EagI", "RsrII", "KpnI", "MluI", "SbfI", "NcoI", "DpnI"]


def filter_enzymes_not_in_sequence(dna):
    """Filter enzymes that are not already present in the sequence"""
    return [e for e in CommOnly if str(e.site) not in dna]


def rank_results_by_preference(results):
    """Rank results by enzyme preference"""
    preferred = get_preferred_enzymes()
    results_df = pd.DataFrame(results)
    
    if results_df.empty:
        return results_df, []
    
    # Add preference score (lower is better)
    results_df['preference_score'] = results_df['enzyme'].astype(str).apply(
        lambda x: preferred.index(x) if x in preferred else len(preferred)
    )
    
    # Sort by preference, then by number of changes (fewer is better)
    results_df = results_df.sort_values(['preference_score', 'removed_bases'])
    
    # Get matched preferred enzymes  
    matched_series = results_df[results_df['enzyme'].astype(str).isin(preferred)]['enzyme'].astype(str)
    matched_enzymes = matched_series.drop_duplicates().tolist()
    
    return results_df, matched_enzymes


def score_results_with_codon_optimization(results, original_seq, 
                                         host_organism="ecoli",
                                         weights=None):
    """
    Score silent mutation results using algorithmic codon optimization
    
    Args:
        results: List of results from find_silent_sites
        original_seq: Original DNA sequence
        host_organism: 'ecoli', 'human', or custom codon usage dict
        weights: Custom scoring weights
    
    Returns: DataFrame with scored and ranked results
    """
    if not results:
        return pd.DataFrame()
    
    optimizer = CodonOptimizer(host_organism=host_organism)
    
    scored_results = []
    for result in results:
        mutated = result.get('mutated')
        orig_window = result.get('orig_window') or result.get('original_window')

        # Use the codon-aligned original window when scoring (ensure equal lengths)
        if not orig_window or not mutated or len(orig_window) != len(mutated):
            # Skip inconsistent entries
            continue

        # Check if this mutation introduces a restriction site (by design true)
        has_restriction_site = True

        # Score the variant using the orig_window as the original sequence
        scores = optimizer.score_variant(
            orig_window,
            mutated,
            has_restriction_site=has_restriction_site,
            weights=weights
        )

        # Merge scores into result and include both sequences explicitly
        result_with_scores = result.copy()
        result_with_scores.update(scores)
        result_with_scores['original_seq'] = orig_window
        result_with_scores['variant_seq'] = mutated
        scored_results.append(result_with_scores)
    
    # Convert to DataFrame
    results_df = pd.DataFrame(scored_results)
    
    # Sort by total score (highest first)
    if 'total_score' in results_df.columns:
        results_df = results_df.sort_values('total_score', ascending=False)
        # Assign rank (1 = best)
        results_df = results_df.reset_index(drop=True)
        results_df['rank'] = results_df.index + 1
    
    return results_df


def export_scored_results_to_csv(results_df, filename="codon_optimized_results.csv"):
    """Export scored results to CSV with all scoring metrics"""
    if results_df.empty:
        return filename
    
    # Select relevant columns for export
    export_cols = [
        'enzyme', 'mutated', 'aa', 'codon_changes',
        'cai', 'rare_penalty', 'structure_penalty', 
        'mutation_penalty', 'restriction_bonus', 'total_score'
    ]
    
    # Only include columns that exist
    available_cols = [col for col in export_cols if col in results_df.columns]
    
    results_df[available_cols].to_csv(filename, index=False)
    return filename


def get_top_codon_optimized_variants(results_df, top_n=5):
    """Get top N variants by codon optimization score"""
    if results_df.empty or 'total_score' not in results_df.columns:
        return []
    
    top_variants = results_df.nlargest(top_n, 'total_score')
    return top_variants.to_dict('records')
