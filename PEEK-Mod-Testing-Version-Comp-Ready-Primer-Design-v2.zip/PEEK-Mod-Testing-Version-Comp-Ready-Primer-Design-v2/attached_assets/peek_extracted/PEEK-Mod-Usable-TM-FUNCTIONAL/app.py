import os
import pandas as pd
from flask import Flask, request, render_template, jsonify, send_file, flash, redirect, url_for

# Import the working algorithm
from silent_mutation_engine import (
    find_silent_sites, 
    filter_enzymes_not_in_sequence, 
    rank_results_by_preference,
    save_results_to_csv,
    get_preferred_enzymes,
    score_results_with_codon_optimization,
    export_scored_results_to_csv,
    get_top_codon_optimized_variants
)
from motif_library import get_motif_library
from Bio.Seq import Seq
from Bio.Restriction import CommOnly
from Bio.SeqUtils import MeltingTemp as mt
import math
import statistics

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key-for-peek")

# ---------- CONFIG ----------
NEB_CORR = 18.0  # Empirical offset to match NEB (adjust based on your test primers)
FORWARD_CORR = 9.0  # Additional correction for forward primers
MIN_PRIMER_LEN = 15
MAX_COMBINED = 60
MAX_TM_DIFF = 5.0
TARGET_TM = 68.0  # avg Tm target for primer design
NEB_ANNEAL_OFFSET = 3  # NEB-style annealing = avg_tm + 3

Q5_NA = 50  # mM monovalent
Q5_MG = 2   # mM Mg++
Q5_dNTP = 0.2  # mM dNTP
PRIMER_CONC = 500e-9  # 500 nM primer


def validate_dna_sequence(sequence):
    """Validate DNA sequence input"""
    if not sequence:
        return False, "Please enter a DNA sequence"
    
    # Check for valid nucleotides only
    valid_bases = set('ATCG')
    sequence_bases = set(sequence.upper())
    
    if not sequence_bases.issubset(valid_bases):
        invalid_bases = sequence_bases - valid_bases
        return False, f"Invalid characters found: {', '.join(invalid_bases)}. Only A, T, C, G are allowed."
    
    return True, "Valid DNA sequence"


def tm_nn_neb(primer):
    """Nearest-neighbor Tm + empirical NEB offset"""
    if not primer:
        return 0.0, 0.0
    try:
        tm_raw = mt.Tm_NN(primer, nn_table=mt.DNA_NN4,
                           Na=Q5_NA, Mg=Q5_MG, dNTPs=Q5_dNTP,
                           dnac1=PRIMER_CONC, dnac2=PRIMER_CONC)
    except:
        tm_raw = 0.0
    tm_corr = tm_raw + NEB_CORR
    gc = 100.0 * (primer.count("G") + primer.count("C")) / len(primer)
    return round(tm_corr, 1), round(gc, 1)


def calculate_tm(seq):
    """Calculate Tm using the new NEB-corrected method"""
    return tm_nn_neb(seq)[0]  # Just return Tm, not GC%


def calculate_gc_content(seq):
    """Calculate GC content percentage"""
    gc_count = seq.count('G') + seq.count('C')
    return round((gc_count / len(seq)) * 100, 1) if seq else 0




def reverse_complement(seq):
    """Get reverse complement of DNA sequence"""
    complement = {'A': 'T', 'T': 'A', 'G': 'C', 'C': 'G'}
    return ''.join(complement[base] for base in reversed(seq))


def design_primer_pair(avail_forward, avail_reverse_rc, site_prefix=""):
    """Primer pair optimizer ensuring balanced Tm within 5°C"""
    best = None
    max_f = min(len(avail_forward)+len(site_prefix), MAX_COMBINED - MIN_PRIMER_LEN)
    
    for f_len in range(MIN_PRIMER_LEN, max_f+1):
        f_take = max(0, f_len - len(site_prefix))
        f_primer = (site_prefix + avail_forward[:f_take])[:f_len]
        f_tm_raw, f_gc = tm_nn_neb(f_primer)
        f_tm = f_tm_raw + FORWARD_CORR  # Apply additional correction to forward primer
        
        max_r = min(len(avail_reverse_rc), MAX_COMBINED - len(f_primer))
        if max_r < MIN_PRIMER_LEN:
            continue
            
        # Search for reverse primer length that balances Tm
        for r_len in range(MIN_PRIMER_LEN, max_r+1):
            r_primer = avail_reverse_rc[:r_len]
            r_tm, r_gc = tm_nn_neb(r_primer)  # Keep reverse primer as-is
            
            tm_diff = abs(f_tm - r_tm)
            # Only consider primers within 5°C difference
            if tm_diff > MAX_TM_DIFF:
                continue
                
            avg_tm = (f_tm + r_tm)/2
            combined_len = len(f_primer)+len(r_primer)
            
            # Ensure recommended annealing temp is above 55°C
            recommended_anneal = avg_tm + NEB_ANNEAL_OFFSET
            if recommended_anneal < 55.0:
                continue
            
            # Prioritize: 1) Small Tm difference, 2) Close to target Tm, 3) Shorter length
            score = (tm_diff, abs(avg_tm - TARGET_TM), combined_len)
            
            if best is None or score < best["score"]:
                best = {
                    "f_primer": f_primer, "f_tm": f_tm, "f_gc": f_gc,
                    "r_primer": r_primer, "r_tm": r_tm, "r_gc": r_gc,
                    "avg_tm": round(avg_tm,1), "combined_len": combined_len,
                    "tm_diff": round(tm_diff, 1),
                    "recommended_anneal": int(round(avg_tm + NEB_ANNEAL_OFFSET)),
                    "score": score
                }
    return best


def design_optimal_primer_pair(avail_forward, avail_reverse_rc,
                               min_len=MIN_PRIMER_LEN, max_total=MAX_COMBINED,
                               target_tm=TARGET_TM, max_diff=MAX_TM_DIFF,
                               enzyme_site_prefix=""):
    """Wrapper for compatibility with existing code"""
    return design_primer_pair(avail_forward, avail_reverse_rc, site_prefix=enzyme_site_prefix)


def get_enzyme_site_dict(dna_sequence=None):
    """Get dictionary of enzyme names to recognition sites, optionally filtered by DNA sequence"""
    enzyme_dict = {}
    for enzyme in CommOnly:
        site = str(enzyme.site)
        if 'N' not in site and len(site) <= 8:  # Filter out ambiguous and very long sites
            # If DNA sequence provided, only include enzymes whose sites don't already exist
            if dna_sequence is None or site not in dna_sequence:
                enzyme_dict[enzyme.__name__] = site
    return enzyme_dict


def aa_to_dna(aa_seq):
    """Convert amino acid sequence to DNA using simplified codon table"""
    table = {'A':'GCT','R':'CGT','N':'AAT','D':'GAT','C':'TGT',
             'Q':'CAA','E':'GAA','G':'GGT','H':'CAT','I':'ATT',
             'L':'TTA','K':'AAA','M':'ATG','F':'TTT','P':'CCT',
             'S':'TCT','T':'ACT','W':'TGG','Y':'TAT','V':'GTT','*':'TAA'}
    dna = ""
    for aa in aa_seq:
        if aa not in table:
            raise ValueError(f"Invalid AA: {aa}")
        dna += table[aa]
    return dna


def design_enzyme_primers(dna, position, enzyme_name, enzyme_site):
    """Design optimal primers for enzyme insertion using simplified algorithm"""
    # Position is 1-based, convert to 0-based
    pos = position - 1
    
    # Create modified sequence with enzyme site inserted
    mod = dna[:pos] + enzyme_site + dna[pos:]
    
    # Get available sequences for primer design
    f_start = pos + len(enzyme_site)
    avail_f = mod[f_start:f_start + MAX_COMBINED]
    r_end = pos
    avail_r = mod[max(0, r_end - MAX_COMBINED):r_end]
    avail_r_rc = reverse_complement(avail_r)
    
    # Design primers with enzyme site prefix
    primers = design_primer_pair(avail_f, avail_r_rc, site_prefix=enzyme_site)
    
    if primers:
        return {
            'enzyme_name': enzyme_name,
            'f_primer': primers['f_primer'],
            'r_primer': primers['r_primer'],
            'f_tm': primers['f_tm'],
            'r_tm': primers['r_tm'], 
            'f_gc': primers['f_gc'],
            'r_gc': primers['r_gc'],
            'avg_tm': primers['avg_tm'],
            'recommended_anneal': primers['recommended_anneal'],
            'insertion_point': f"Position {position} in sequence"
        }
    else:
        # Return None if design fails - caller can handle error
        return None


def design_insertion_primers(dna, position, aa_sequence):
    """Design optimal primers for amino acid insertion using simplified algorithm"""
    # Convert amino acid to nucleotides using simplified codon table
    insert_nt = aa_to_dna(aa_sequence)
    
    # Position is 1-based, convert to 0-based
    pos = position - 1
    
    # Create modified sequence with insertion
    mod = dna[:pos] + insert_nt + dna[pos:]
    
    # Get available sequences for primer design
    f_start = pos + len(insert_nt)
    avail_f = mod[f_start:f_start + MAX_COMBINED]
    r_end = pos
    avail_r = mod[max(0, r_end - MAX_COMBINED):r_end]
    avail_r_rc = reverse_complement(avail_r)
    
    # Design primers with amino acid insert as prefix for forward primer
    primers = design_primer_pair(avail_f, avail_r_rc, site_prefix=insert_nt)
    
    # Design homology arms (20 nt each) for synthesis template
    arm_length = 20
    left_arm = dna[max(0, pos - arm_length):pos]
    right_arm = dna[pos:min(len(dna), pos + arm_length)]
    homology_full = left_arm + insert_nt + right_arm
    
    if primers:
        return {
            'left_arm': left_arm,
            'insert_nt': insert_nt,
            'right_arm': right_arm,
            'homology_full': homology_full,
            'f_primer': primers['f_primer'],
            'r_primer': primers['r_primer'],
            'f_tm': primers['f_tm'],
            'r_tm': primers['r_tm'],
            'f_gc': primers['f_gc'],
            'r_gc': primers['r_gc'],
            'avg_tm': primers['avg_tm'],
            'recommended_anneal': primers['recommended_anneal'],
            'insertion_point': f"Position {position} in sequence"
        }
    else:
        # Return None if design fails - caller can handle error
        return None


@app.route('/')
def index():
    return redirect('/silent-mutations')

@app.route('/home')
def home():
    return redirect('/silent-mutations')


@app.route('/silent-mutations', methods=['GET', 'POST'])
def silent_mutations():
    if request.method == 'GET':
        return render_template('silent_mutations.html')

    try:
        # Get form data
        dna = request.form.get('dna', '').strip().upper().replace('\n', '').replace(' ', '')
        cut_pos = int(request.form.get('cut_pos', 0))
        tolerance = int(request.form.get('tolerance', 3))
        window_codons = int(request.form.get('window_codons', 10))
        max_changes = int(request.form.get('max_changes', 3))
        host_organism = request.form.get('host_organism', 'ecoli')
        enable_optimization = request.form.get('enable_optimization', 'on') == 'on'

        # Validate inputs
        is_valid, message = validate_dna_sequence(dna)
        if not is_valid:
            flash(f"Invalid DNA sequence: {message}", "error")
            return render_template('silent_mutations.html', error=message,
                                 dna=dna, cut_pos=cut_pos, tolerance=tolerance,
                                 window_codons=window_codons, max_changes=max_changes)

        if cut_pos <= 0 or cut_pos > len(dna):
            flash(f"Cut position ({cut_pos}) must be between 1 and {len(dna)}", "error")
            return render_template('silent_mutations.html', error="Invalid cut position",
                                 dna=dna, cut_pos=cut_pos, tolerance=tolerance,
                                 window_codons=window_codons, max_changes=max_changes)

        # Convert to 0-based indexing
        cut_pos_0based = cut_pos - 1

        # Filter enzymes not in sequence
        available_enzymes = filter_enzymes_not_in_sequence(dna)

        # Find silent sites
        results = find_silent_sites(
            dna,
            cut_pos_0based,
            tolerance,
            window_codons,
            available_enzymes,
            coding_start_pos=1,
            max_changes=max_changes
        )

        if not results:
            flash("No valid silent mutations found with the given parameters.", "warning")
            return render_template('silent_mutations.html',
                                 error="No results found. Try increasing tolerance or window size.",
                                 dna=dna, cut_pos=cut_pos, tolerance=tolerance,
                                 window_codons=window_codons, max_changes=max_changes)

        # Score or rank results
        if enable_optimization:
            try:
                results_df = score_results_with_codon_optimization(results, dna, host_organism=host_organism)
                ranked_results = results_df.to_dict('records')
                top_variants = get_top_codon_optimized_variants(results_df, top_n=10)
            except Exception as opt_error:
                print(f"Codon optimization error: {opt_error}")
                results_df, matched_preferred = rank_results_by_preference(results)
                ranked_results = results_df.to_dict('records')
                top_variants = ranked_results[:10]
        else:
            results_df, matched_preferred = rank_results_by_preference(results)
            ranked_results = results_df.to_dict('records')
            top_variants = ranked_results[:10]

        # Get summary stats
        summary = {
            'total_results': len(results),
            'optimization_enabled': enable_optimization,
            'host_organism': host_organism,
            'unique_enzymes': results_df['enzyme'].astype(str).nunique() if not results_df.empty else 0,
            'avg_changes': results_df['removed_bases'].str.len().mean() if not results_df.empty else 0,
        }

        if not enable_optimization and 'matched_preferred' in locals():
            summary['preferred_enzymes'] = len(matched_preferred)
            summary['matched_preferred_list'] = matched_preferred

        return render_template('silent_mutations.html',
                             results=ranked_results,
                             top_variants=top_variants,
                             summary=summary,
                             success=True,
                             dna=dna,
                             cut_pos=cut_pos,
                             tolerance=tolerance,
                             window_codons=window_codons,
                             max_changes=max_changes,
                             host_organism=host_organism,
                             enable_optimization=enable_optimization)

    except ValueError as e:
        flash(f"Invalid input: {str(e)}", "error")
        return render_template('silent_mutations.html', error="Invalid numerical input")
    except Exception as e:
        flash(f"An error occurred: {str(e)}", "error")
        return render_template('silent_mutations.html', error="Processing error occurred")
@app.route('/download-csv')
def download_csv():
    """Download results as CSV"""
    try:
        # This would need to be called after results are generated
        # For now, return a simple response
        return "CSV download feature - results need to be stored in session first"
    except Exception as e:
        flash(f"Error downloading CSV: {str(e)}", "error")
        return redirect(url_for('silent_mutations'))


@app.route('/primer-design', methods=['GET', 'POST'])
def primer_design():
    if request.method == 'GET':
        # Get available enzymes for the dropdown
        available_enzymes = get_enzyme_site_dict()
        motif_library = get_motif_library()
        return render_template('primer_design.html', available_enzymes=available_enzymes, motif_library=motif_library)
    
    try:
        # Get form data
        dna = request.form.get('dna', '').strip().upper().replace('\n', '').replace(' ', '')
        pos = int(request.form.get('pos', 0))
        mode = request.form.get('mode', 'enzyme')
        
        # Validate DNA sequence
        is_valid, message = validate_dna_sequence(dna)
        if not is_valid:
            flash(f"Invalid DNA sequence: {message}", "error")
            available_enzymes = get_enzyme_site_dict()
            return render_template('primer_design.html',
                                 error=message,
                                 available_enzymes=available_enzymes,
                                 motif_library=motif_library,
                                 dna=dna, pos=pos, mode=mode)
        
        # Validate position
        if pos <= 0 or pos > len(dna):
            flash(f"Position ({pos}) must be between 1 and {len(dna)}", "error")
            available_enzymes = get_enzyme_site_dict()
            return render_template('primer_design.html', 
                                 error="Invalid position",
                                 available_enzymes=available_enzymes,
                                 dna=dna, pos=pos, mode=mode)
        
        # Get available enzymes for the dropdown, filtered to exclude those already in sequence
        available_enzymes = get_enzyme_site_dict(dna)
        motif_library = get_motif_library()
        
        enzyme_result = None
        insert_result = None
        
        if mode == 'enzyme':
            # Enzyme insertion mode
            enzyme_name = request.form.get('enzyme_name')
            if not enzyme_name:
                flash("Please select an enzyme", "error")
                return render_template('primer_design.html',
                                         error="No enzyme selected",
                                         available_enzymes=available_enzymes,
                                         motif_library=motif_library,
                                         dna=dna, pos=pos, mode=mode)
            
            # Check if enzyme exists in our list
            if enzyme_name not in available_enzymes:
                flash("Selected enzyme not found", "error")
                return render_template('primer_design.html',
                                         error="Invalid enzyme selection",
                                         available_enzymes=available_enzymes,
                                         motif_library=motif_library,
                                         dna=dna, pos=pos, mode=mode)
            
            enzyme_site = available_enzymes[enzyme_name]
            
            
            
            # Design enzyme insertion primers
            enzyme_result = design_enzyme_primers(dna, pos, enzyme_name, enzyme_site)
            
            # Check if primer design failed
            if enzyme_result is None:
                flash("Could not design primer pair meeting constraints (min len, max combined, ΔTm). Consider providing more flanking sequence.", "error")
                return render_template('primer_design.html',
                                         error="Primer design failed",
                                         available_enzymes=available_enzymes,
                                         motif_library=motif_library,
                                         dna=dna, pos=pos, mode=mode,
                                         enzyme_name=enzyme_name)
            
        else:
            # Amino acid insertion mode
            aa_seq = request.form.get('aa_seq', '').strip().upper()
            if not aa_seq:
                flash("Please enter an amino acid sequence", "error")
                return render_template('primer_design.html',
                                     error="No amino acid sequence provided",
                                     available_enzymes=available_enzymes,
                                     dna=dna, pos=pos, mode=mode)
            
            # Validate amino acid sequence
            valid_aas = set('ARNDCQEGHILKMFPSTWYV')
            if not set(aa_seq).issubset(valid_aas):
                invalid_aas = set(aa_seq) - valid_aas
                flash(f"Invalid amino acids: {', '.join(invalid_aas)}", "error")
                return render_template('primer_design.html',
                                     error="Invalid amino acid sequence",
                                     available_enzymes=available_enzymes,
                                     dna=dna, pos=pos, mode=mode, aa_seq=aa_seq)
            
            # Design insertion primers
            insert_result = design_insertion_primers(dna, pos, aa_seq)
            
            # Check if primer design failed
            if insert_result is None:
                flash("Could not design primer pair meeting constraints (min len, max combined, ΔTm). Consider providing more flanking sequence.", "error")
                return render_template('primer_design.html',
                                         error="Primer design failed",
                                         available_enzymes=available_enzymes,
                                         motif_library=motif_library,
                                         dna=dna, pos=pos, mode=mode, aa_seq=aa_seq)
            
            # Check if homology sequence is too long
            if len(insert_result['homology_full']) > 60:
                flash(f"Warning: Homology sequence is {len(insert_result['homology_full'])} nt (>60 nt may be difficult to synthesize)", "warning")
        
        return render_template('primer_design.html',
                                 available_enzymes=available_enzymes,
                                 motif_library=motif_library,
                                 enzyme_result=enzyme_result,
                                 insert_result=insert_result,
                                 dna=dna,
                                 pos=pos,
                                 mode=mode,
                                 aa_seq=request.form.get('aa_seq', '') if mode == 'insert' else '',
                                 enzyme_name=request.form.get('enzyme_name', '') if mode == 'enzyme' else '')
        
    except ValueError as e:
        flash(f"Invalid input: {str(e)}", "error")
        available_enzymes = get_enzyme_site_dict()
        motif_library = get_motif_library()
        owned_enzymes = request.form.get('owned_enzymes', '').strip()
        return render_template('primer_design.html', 
                             error="Invalid numerical input",
                             available_enzymes=available_enzymes,
                             motif_library=motif_library,
                             owned_enzymes=owned_enzymes)
    except Exception as e:
        flash(f"An error occurred: {str(e)}", "error")
        available_enzymes = get_enzyme_site_dict()
        motif_library = get_motif_library()
        owned_enzymes = request.form.get('owned_enzymes', '').strip()
        return render_template('primer_design.html', 
                             error="Processing error occurred",
                             available_enzymes=available_enzymes,
                             motif_library=motif_library,
                             owned_enzymes=owned_enzymes)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)