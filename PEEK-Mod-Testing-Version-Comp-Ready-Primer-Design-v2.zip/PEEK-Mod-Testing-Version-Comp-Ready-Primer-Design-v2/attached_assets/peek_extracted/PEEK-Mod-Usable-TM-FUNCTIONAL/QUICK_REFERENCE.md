# Quick Reference: Codon Optimization Scoring in PEEK-Mod

## What's New?

The Silent Mutations analyzer now includes **algorithmic codon optimization scoring**. Each variant is scored across 5 dimensions, and results are ranked by total score.

## Quick Start (Web UI)

1. Go to **Silent Mutations** page
2. Enter your DNA sequence and parameters (as usual)
3. **Check the box:** "Enable Algorithmic Scoring"
4. **Pick your organism:** E. coli (default) or Human
5. **Click:** "Find Silent Mutations"
6. View results with scoring metrics!

## Understanding the Scores

### CAI (Codon Adaptation Index)
**Green badge** | Range: 0.0 - 1.0 | **Higher = Better**

- Measures how optimized codons are for your host organism
- 0.9+ is excellent, 0.7-0.8 is good, <0.7 needs improvement
- Based on codon frequency in nature

### Rare Penalty
**Warning badge** | Range: 0+ | **Lower = Better**

- Penalizes clusters of rare codons (that slow translation)
- 0 = no problems, >0 = some issues detected
- Each cluster costs 0.1 penalty points

### Structure Penalty  
**Info badge** | Range: 0+ | **Lower = Better**

- Measures overly stable secondary structures
- Based on RNA folding energy (ΔG)
- Stable structures block ribosomes = slow translation
- Penalizes if ΔG < -2 kcal/mol

### Total Score
**Primary badge** | Range: Any | **Higher = Better**

- Composite score combining all metrics
- Formula: CAI - 0.5×RarePenalty - 0.3×StructPenalty - 0.1×MutationPenalty + RestrictionBonus
- Results ranked by this score (best first)

## What's Behind Each Score?

| Metric | What It Measures | Why It Matters |
|--------|------------------|----------------|
| **CAI** | Codon optimization | Directly affects protein expression level |
| **Rare Codons** | Codon clusters | Clusters cause ribosomal stalling |
| **Structure** | mRNA secondary structure | Stable folds block ribosome progress |
| **Mutations** | Number of changes | Fewer changes = lower risk |

## Interpreting Results

### Example Result Row
```
Rank 1 | BamHI | 5 | CAI: 0.934 | Rare: 0.000 | Struct: 0.025 | Score: 1.411
```

**What this means:**
- ✓ Top-ranked variant
- ✓ Very high CAI (0.934)
- ✓ No rare codon clusters
- ✓ Minimal structure penalty (0.025)
- ✓ Highest overall score (1.411)
- **→ This is the best choice for expression optimization**

---

### Another Example
```
Rank 8 | EcoRI | 12 | CAI: 0.812 | Rare: 0.200 | Struct: 0.150 | Score: 0.346
```

**What this means:**
- ✗ Mid-ranked variant
- ⚠ Good but not great CAI (0.812)
- ⚠ Some rare codon clusters (penalty: 0.200)
- ⚠ Moderate structure issue (penalty: 0.150)
- ✗ Lower overall score (0.346)
- **→ Consider if enzyme choice is critical, but suboptimal for expression**

---

## Choosing Between Results

### If you want the BEST expression level:
→ Pick **Rank 1** (highest total score)

### If you want a SPECIFIC enzyme:
→ Find its rank in the results  
→ Check the score - if it's in top 5, still quite good  
→ If it's ranked lower, expect reduced expression

### If you want the FEWEST codon changes:
→ Look at the "Sequence Changes" column  
→ Lower number = more conservative edit

### If you need robust secondary structure:
→ Pick variant with lowest "Struct. Penalty"

---

## Host Organisms

### E. coli (Default)
- Fast translation, high expression
- Used in most research labs
- Prefers certain codons

### Human
- Slower translation (natural)
- For human cell expression systems
- Different codon preferences than E. coli

## Frequently Asked Questions

**Q: What if I disable "Algorithmic Scoring"?**  
A: Results use the old ranking method (enzyme preference only)

**Q: Can I trust these scores?**  
A: Yes! They're based on published biological research, not AI guessing

**Q: What's the difference between CAI and the total score?**  
A: CAI is ONE component. Total score combines all metrics for overall quality

**Q: Why does my top enzyme have a low CAI?**  
A: Enzymes are ranked by restriction site availability first. CAI is one factor among many.

**Q: Can I adjust the scoring weights?**  
A: Not in the UI yet, but developers can edit `codon_optimizer.py` to customize

**Q: What if I have a different organism (not E. coli or Human)?**  
A: Email the development team to add your organism's codon usage table

---

## Tips for Best Results

1. **Enable algorithmic scoring** - It really helps optimize variants
2. **Choose your host organism** - Huge impact on which codons are optimal
3. **Check the top 5 variants** - Often similarly good scores, pick based on other factors
4. **Note the metrics** - All information is transparent and explainable
5. **Copy your favorite sequence** - Click the copy button on any row
6. **Export results** - CSV export includes all metrics for analysis

---

## Troubleshooting

**No results show up?**
- Try increasing "Tolerance" (search radius)
- Try increasing "Window Size" (codons to modify)
- Try increasing "Max Changes" (allowed mutations)

**Scores seem wrong?**
- Make sure sequences are truly synonymous (same amino acids)
- Check that organism selection matches your system
- Some sequences may legitimately have low scores

**Optimization takes a long time?**
- RNA folding calculations can be slow for long sequences
- This is normal - algorithm is thorough
- Results are worth the wait!

---

## More Information

For detailed technical documentation, see:
- **CODON_OPTIMIZATION_ALGORITHM.md** - Full algorithm details
- **IMPLEMENTATION_SUMMARY.md** - Implementation overview

## Contact

Questions about the scoring? See the help modal (?) on the Silent Mutations page.

---

**Version:** 1.0 | **Date:** January 2026 | **Status:** Production Ready
