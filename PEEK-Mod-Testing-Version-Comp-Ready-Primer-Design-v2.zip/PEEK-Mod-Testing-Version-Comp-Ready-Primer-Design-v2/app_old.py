import os
import csv
import io
import itertools
import pandas as pd
from flask import Flask, request, render_template, jsonify, send_file, flash, redirect, url_for

# Import from your original silent mutation engine
from Bio.Seq import Seq
from Bio.Data import CodonTable
from Bio.Restriction import CommOnly, AllEnzymes

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key-for-peek")

# Setup codon tables - EXACT FROM YOUR ORIGINAL CODE
standard_table = CodonTable.unambiguous_dna_by_name["Standard"]
SYNONYMOUS = {}
for codon, aa in standard_table.forward_table.items():
    SYNONYMOUS.setdefault(aa, []).append(codon)
CODON_TO_AA = standard_table.forward_table

# Build enzyme dict for primer design
neb_enzymes = {}
for enz in AllEnzymes:
    if enz.site:
        neb_enzymes[enz.__name__] = enz.site.upper()

# === SILENT MUTATION ENGINE - EXACT FROM YOUR ORIGINAL CODE ===

def translate(seq):
    """Translate DNA sequence to amino acids"""
    return str(Seq(seq).translate())


def get_synonymous(codon):
    """Get synonymous codons for a given codon"""
    aa = CODON_TO_AA.get(codon, None)
    if not aa:
        return [codon]
    return [syn for syn in SYNONYMOUS[aa] if syn != codon]


def site_in_window(seq, enzyme, cut_pos, tolerance):
    """Check if enzyme recognition site is within tolerance of cut position"""
    rec = str(enzyme.site)
    rec_len = len(rec)
    cut_index = enzyme.fst5 if enzyme.fst5 is not None else 0
    for i in range(len(seq) - rec_len + 1):
        if seq[i:i + rec_len] == rec:
            cut_site = i + cut_index
            if abs(cut_site - cut_pos) <= tolerance:
                return cut_site
    return None


def is_valid_window(seq):
    """Check if window is valid (divisible by 3 and no stop codons)"""
    return len(seq) % 3 == 0 and "*" not in translate(seq)


def get_codon_aligned_window(dna_len, cut_pos, window_codons, coding_start_pos=0):
    """Get codon-aligned window around cut position"""
    frame_offset = coding_start_pos % 3
    
    adjusted_pos = cut_pos - frame_offset
    if adjusted_pos < 0:
        codon_start = frame_offset
    else:
        codon_start = cut_pos - (adjusted_pos % 3)
    
    half_window = window_codons // 2
    
    start = codon_start - half_window * 3
    end = codon_start + (window_codons - half_window) * 3
    
    start = max(0, start)
    end = min(dna_len, end)
    
    # Adjust start and end to maintain frame relative to coding_start_pos
    if (start - frame_offset) % 3 != 0:
        start += 3 - ((start - frame_offset) % 3)
    if (end - frame_offset) % 3 != 0:
        end -= ((end - frame_offset) % 3)
    
    return start, end, codon_start


def find_silent_sites(dna, cut_pos, tolerance, window_codons, enzymes, coding_start_pos=0, max_changes=3):
    """Find silent mutations that introduce restriction enzyme sites"""
    results = []
    start, end, codon_start = get_codon_aligned_window(len(dna), cut_pos, window_codons, coding_start_pos)
    window = dna[start:end]
    
    if not is_valid_window(window):
        return []
    
    codons = [window[i:i + 3] for i in range(0, len(window), 3)]
    codon_indices = [i for i, codon in enumerate(codons) if get_synonymous(codon)]
    orig_aa = translate(window)
    
    # Prioritize preferred enzymes for faster results
    preferred_enzymes = get_preferred_enzymes()
    preferred_set = set(preferred_enzymes)
    priority_enzymes = [e for e in enzymes if str(e) in preferred_set]
    other_enzymes = [e for e in enzymes if str(e) not in preferred_set]
    
    # Process preferred enzymes first, then others
    enzyme_list = priority_enzymes + other_enzymes
    
    # Limit search space for performance
    max_combinations = min(1000, len(enzyme_list) * 10)  # Reasonable limit
    combinations_tested = 0
    
    for k in range(1, min(max_changes + 1, len(codon_indices) + 1)):
        for combo in itertools.combinations(codon_indices, k):
            if combinations_tested >= max_combinations:
                break
                
            syn_options = [get_synonymous(codons[i]) for i in combo]
            for replacements in itertools.product(*syn_options):
                if combinations_tested >= max_combinations:
                    break
                    
                combinations_tested += 1
                new_codons = codons[:]
                for idx, new_codon in zip(combo, replacements):
                    new_codons[idx] = new_codon
                mutated = ''.join(new_codons)
                if translate(mutated) != orig_aa:
                    continue
                    
                for enzyme in enzyme_list:
                    cut = site_in_window(mutated, enzyme, cut_pos - start, tolerance)
                    if cut is not None:
                        # Determine removed sequence (difference from original)
                        removed_bases = ''.join([o for o, m in zip(window, mutated) if o != m])
                        side = "5'" if mutated.find(str(enzyme.site)) < len(mutated) // 2 else "3'"
                        
                        results.append({
                            'enzyme': enzyme,
                            'new_cut': start + cut,
                            'orig_window': window,
                            'mutated': mutated,
                            'aa': translate(mutated),
                            'window_start': start,
                            'window_end': end,
                            'codon_start': codon_start,
                            'removed_bases': removed_bases,
                            'removed_side': side
                        })
                        
                        # Stop early if we found enough preferred results
                        if len(results) >= 50 and str(enzyme) in preferred_set:
                            return results
            
            if combinations_tested >= max_combinations:
                break
    
    return results


def save_results_to_csv(results, filename="silent_mutation_results.csv"):
    """Save results to CSV file"""
    with open(filename, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([
            "Result #", "Enzyme", "Recognition Site", "New Cut Position (0-based)",
            "Original Window Start", "Original Window End", "Codon Start in Window",
            "Original Window", "Mutated Window", "Amino Acids",
            "Removed Bases", "Removed Side (5'/3')"
        ])
        for i, result in enumerate(results, 1):
            writer.writerow([
                i,
                str(result['enzyme']),
                result['enzyme'].site,
                result['new_cut'],
                result['window_start'],
                result['window_end'],
                result['codon_start'],
                result['orig_window'],
                result['mutated'],
                result['aa'],
                result['removed_bases'],
                result['removed_side']
            ])
    return filename


def get_preferred_enzymes():
    """Get list of preferred enzymes"""
    return ["SalI", "EagI", "RsrII", "KpnI", "MluI", "SbfI", "NcoI", "DpnI"]


def filter_enzymes_not_in_sequence(dna):
    """Filter enzymes that are not already present in the sequence"""
    return [e for e in CommOnly if str(e.site) not in dna]


def rank_results_by_preference(results):
    """Rank results by enzyme preference"""
    preferred = get_preferred_enzymes()
    results_df = pd.DataFrame(results)
    
    if results_df.empty:
        return results_df, []
    
    # Add preference score (lower is better)
    results_df['preference_score'] = results_df['enzyme'].astype(str).apply(
        lambda x: preferred.index(x) if x in preferred else len(preferred)
    )
    
    # Sort by preference, then by number of changes (fewer is better)
    results_df = results_df.sort_values(['preference_score', 'removed_bases'])
    
    # Get matched preferred enzymes  
    matched_mask = results_df['enzyme'].astype(str).isin(preferred)
    matched_enzymes = results_df.loc[matched_mask, 'enzyme'].astype(str).drop_duplicates().tolist()
    
    return results_df, matched_enzymes

# === PRIMER DESIGN FUNCTIONS ===

def calc_tm_q5(primer, correction=7.0):
    """Calculate melting temperature using Q5 formula"""
    length = len(primer)
    gc = primer.count("G") + primer.count("C")
    gc_percent = 100.0 * gc / length if length > 0 else 0
    tm = 64.9 + 0.41 * gc_percent - (500.0 / length) + correction if length > 0 else 0
    return round(tm, 1), round(gc_percent, 1)

def optimize_primer(seq, min_len=15, max_len=30, target_tm=68.0):
    """Optimize primer length for target melting temperature"""
    best = seq[:min_len]
    best_tm, _ = calc_tm_q5(best)
    for L in range(min_len, min(len(seq), max_len) + 1):
        candidate = seq[:L]
        tm, _ = calc_tm_q5(candidate)
        if abs(tm - target_tm) < abs(best_tm - target_tm):
            best = candidate
            best_tm = tm
    return best, calc_tm_q5(best)

def aa_to_dna(aa_seq):
    """Convert amino acid sequence to DNA using standard codon table"""
    codon_table_std = {
        'A': 'GCT', 'R': 'CGT', 'N': 'AAT', 'D': 'GAT', 'C': 'TGT',
        'Q': 'CAA', 'E': 'GAA', 'G': 'GGT', 'H': 'CAT', 'I': 'ATT',
        'L': 'TTA', 'K': 'AAA', 'M': 'ATG', 'F': 'TTT', 'P': 'CCT',
        'S': 'TCT', 'T': 'ACT', 'W': 'TGG', 'Y': 'TAT', 'V': 'GTT',
        '*': 'TAA'
    }
    dna_seq = ""
    for aa in aa_seq:
        if aa in codon_table_std:
            dna_seq += codon_table_std[aa]
        else:
            raise ValueError(f"Unknown amino acid: {aa}")
    return dna_seq

def rev_comp(seq):
    """Return reverse complement of DNA sequence"""
    complement = {'A': 'T', 'T': 'A', 'C': 'G', 'G': 'C'}
    return ''.join(complement.get(base, base) for base in reversed(seq))

def validate_dna_sequence(sequence):
    """Validate DNA sequence input"""
    if not sequence:
        return False, "Please enter a DNA sequence"
    
    # Check for valid nucleotides only
    valid_bases = set('ATCG')
    sequence_bases = set(sequence.upper())
    
    if not sequence_bases.issubset(valid_bases):
        invalid_bases = sequence_bases - valid_bases
        return False, f"Invalid characters found: {', '.join(invalid_bases)}. Only A, T, C, G are allowed."
    
    return True, "Valid DNA sequence"

# === FLASK ROUTES ===

@app.route("/")
def home():
    """Main page - Silent Mutation Generator"""
    return silent_mutations()

@app.route("/silent-mutations", methods=["GET", "POST"])
def silent_mutations():
    """Silent mutation generator page"""
    if request.method == "POST":
        try:
            dna = request.form.get("dna", "").strip().upper()
            cut_pos = int(request.form.get("cut_pos", "1")) - 1  # Convert to 0-based
            tolerance = int(request.form.get("tolerance", 5))
            window_codons = int(request.form.get("window_codons", 10))
            max_changes = int(request.form.get("max_changes", 3))
            coding_start_pos = 0  # Use 0 for valid windows

            # Validate DNA sequence
            is_valid, message = validate_dna_sequence(dna)
            if not is_valid:
                flash(message, "error")
                return render_template("silent_mutations.html")

            if cut_pos < 0 or cut_pos >= len(dna):
                flash("Cut position is out of range.", "error")
                return render_template("silent_mutations.html")

            # Get enzymes not already present in sequence
            enzymes = filter_enzymes_not_in_sequence(dna)
            
            # Find silent mutations
            results = find_silent_sites(dna, cut_pos, tolerance, window_codons, enzymes, coding_start_pos, max_changes)
            
            # Rank results by preference
            if results:
                results_df, matched_preferred = rank_results_by_preference(results)
                results = results_df.to_dict('records')
                
                if matched_preferred:
                    flash(f"Found {len(matched_preferred)} preferred enzymes: {', '.join(matched_preferred)}", "success")
                else:
                    flash(f"Found {len(results)} mutations. No preferred enzymes found.", "info")
            else:
                flash("No valid silent mutations found. Try increasing tolerance or window size.", "warning")

            return render_template("silent_mutations.html", 
                                 results=results, 
                                 dna=dna,
                                 cut_pos=cut_pos+1,  # Convert back to 1-based for display
                                 tolerance=tolerance,
                                 window_codons=window_codons,
                                 max_changes=max_changes)

        except ValueError as e:
            flash(f"Invalid input: {str(e)}", "error")
        except Exception as e:
            flash(f"Error processing request: {str(e)}", "error")

    return render_template("silent_mutations.html")

@app.route("/export-csv")
def export_csv():
    """Export silent mutation results to CSV"""
    # Get results from session or re-run analysis
    # For simplicity, we'll expect the results to be passed as parameters
    # In a real application, you'd store results in session
    flash("CSV export functionality requires results to be generated first.", "info")
    return redirect(url_for('silent_mutations'))

@app.route("/primer-design", methods=["GET", "POST"])
def primer_design():
    """Primer design page"""
    if request.method == "POST":
        try:
            mode = request.form.get("mode")
            dna = request.form.get("dna", "").upper().strip()
            pos = int(request.form.get("pos", "1"))

            # Validate inputs
            is_valid, message = validate_dna_sequence(dna)
            if not is_valid:
                flash(message, "error")
                return render_template("primer_design.html")

            if pos < 1 or pos > len(dna):
                flash("Position is out of range.", "error")
                return render_template("primer_design.html")

            results = []

            if mode == "enzyme_insertion":
                enzyme_name = request.form.get("enzyme")
                if enzyme_name not in neb_enzymes:
                    flash("Invalid enzyme selection.", "error")
                    return render_template("primer_design.html")

                site = neb_enzymes[enzyme_name]
                
                # Generate primers for enzyme insertion
                upstream = dna[:pos-1]
                downstream = dna[pos-1:]
                
                # Forward primer with enzyme site
                fwd_seq = upstream[-20:] + site + downstream[:20]
                fwd_primer, (fwd_tm, fwd_gc) = optimize_primer(fwd_seq)
                
                # Reverse primer
                rev_seq = rev_comp(upstream[-20:] + site + downstream[:20])
                rev_primer, (rev_tm, rev_gc) = optimize_primer(rev_seq)
                
                results = [
                    {
                        'type': 'Forward Primer',
                        'sequence': fwd_primer,
                        'tm': fwd_tm,
                        'gc': fwd_gc,
                        'length': len(fwd_primer)
                    },
                    {
                        'type': 'Reverse Primer',
                        'sequence': rev_primer,
                        'tm': rev_tm,
                        'gc': rev_gc,
                        'length': len(rev_primer)
                    }
                ]

            elif mode == "aa_insertion":
                aa_seq = request.form.get("aa_sequence", "").upper()
                if not aa_seq:
                    flash("Please enter amino acid sequence.", "error")
                    return render_template("primer_design.html")

                try:
                    # Convert AA to DNA
                    insert_dna = aa_to_dna(aa_seq)
                    
                    # Generate primers
                    upstream = dna[:pos-1]
                    downstream = dna[pos-1:]
                    
                    # Forward primer with insertion
                    fwd_seq = upstream[-20:] + insert_dna + downstream[:20]
                    fwd_primer, (fwd_tm, fwd_gc) = optimize_primer(fwd_seq)
                    
                    # Reverse primer
                    rev_seq = rev_comp(upstream[-20:] + insert_dna + downstream[:20])
                    rev_primer, (rev_tm, rev_gc) = optimize_primer(rev_seq)
                    
                    results = [
                        {
                            'type': 'Forward Primer',
                            'sequence': fwd_primer,
                            'tm': fwd_tm,
                            'gc': fwd_gc,
                            'length': len(fwd_primer)
                        },
                        {
                            'type': 'Reverse Primer',
                            'sequence': rev_primer,
                            'tm': rev_tm,
                            'gc': rev_gc,
                            'length': len(rev_primer)
                        }
                    ]
                    
                except ValueError as e:
                    flash(f"Error converting amino acids: {str(e)}", "error")
                    return render_template("primer_design.html")

            return render_template("primer_design.html", results=results, mode=mode, 
                                 dna=dna, pos=pos, enzymes=list(neb_enzymes.keys()))

        except ValueError as e:
            flash(f"Invalid input: {str(e)}", "error")
        except Exception as e:
            flash(f"Error processing request: {str(e)}", "error")

    return render_template("primer_design.html", enzymes=list(neb_enzymes.keys()))

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)