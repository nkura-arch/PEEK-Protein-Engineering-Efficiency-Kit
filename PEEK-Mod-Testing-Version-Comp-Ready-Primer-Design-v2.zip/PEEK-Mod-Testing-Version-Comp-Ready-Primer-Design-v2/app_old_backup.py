import os
import csv
import io
import itertools
import pandas as pd
from flask import Flask, request, render_template, jsonify, send_file, flash, redirect, url_for

# Import from Bio - EXACT FROM USER'S WORKING CODE
from Bio.Seq import Seq
from Bio.Data import CodonTable
from Bio.Restriction import CommOnly, AllEnzymes

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key-for-peek")

# === EXACT COPY FROM USER'S WORKING CODE ===

# Setup codon tables
standard_table = CodonTable.unambiguous_dna_by_name["Standard"]
SYNONYMOUS = {}
for codon, aa in standard_table.forward_table.items():
    SYNONYMOUS.setdefault(aa, []).append(codon)
CODON_TO_AA = standard_table.forward_table


def translate(seq):
    return str(Seq(seq).translate())


def get_synonymous(codon):
    aa = CODON_TO_AA.get(codon.upper(), None)
    if not aa:
        return []
    return [syn.lower() for syn in SYNONYMOUS[aa] if syn.lower() != codon.lower()]


def site_in_window(seq, enzyme, cut_pos, tolerance):
    rec = str(enzyme.site).upper()
    seq_upper = seq.upper()
    rec_len = len(rec)
    cut_index = enzyme.fst5 if enzyme.fst5 is not None else 0
    for i in range(len(seq_upper) - rec_len + 1):
        if seq_upper[i:i + rec_len] == rec:
            cut_site = i + cut_index
            if abs(cut_site - cut_pos) <= tolerance:
                return cut_site
    return None


def is_valid_window(seq):
    # Allow windows with stop codons - user's original algorithm handles them
    return len(seq) % 3 == 0


def get_codon_aligned_window(dna_len, cut_pos, window_codons, coding_start_pos=0):
    frame_offset = coding_start_pos % 3

    adjusted_pos = cut_pos - frame_offset
    if adjusted_pos < 0:
        codon_start = frame_offset
    else:
        codon_start = cut_pos - (adjusted_pos % 3)

    half_window = window_codons // 2

    start = codon_start - half_window * 3
    end = codon_start + (window_codons - half_window) * 3

    start = max(0, start)
    end = min(dna_len, end)
    
    # Ensure we have a valid window - if cut position is too close to the end
    if end <= start or (end - start) < 30:  # Minimum 10 codons = 30 bases
        # Try to extend window towards the beginning
        start = max(0, cut_pos - window_codons * 3)
        end = min(dna_len, start + window_codons * 3)
        # If still too small, extend further
        if (end - start) < 30:
            start = max(0, dna_len - window_codons * 3)
            end = dna_len

    # Adjust start and end to maintain frame relative to coding_start_pos
    if (start - frame_offset) % 3 != 0:
        adjustment = 3 - ((start - frame_offset) % 3)
        if start + adjustment < end:
            start += adjustment
    if (end - frame_offset) % 3 != 0:
        end -= ((end - frame_offset) % 3)
        
    # Ensure window length is divisible by 3
    window_length = end - start
    if window_length % 3 != 0:
        end = start + (window_length // 3) * 3
        
    # Final safety check - ensure minimum window size
    if end <= start or (end - start) < 30:
        start = max(0, dna_len - 30)
        end = dna_len
        # Make sure it's divisible by 3
        window_length = end - start
        if window_length % 3 != 0:
            start = end - (window_length // 3) * 3

    return start, end, codon_start


def find_silent_sites(dna, cut_pos, tolerance, window_codons, enzymes, coding_start_pos=0, max_changes=3):
    results = []
    start, end, codon_start = get_codon_aligned_window(len(dna), cut_pos, window_codons, coding_start_pos)
    window = dna[start:end]

    if not is_valid_window(window):
        return []

    codons = [window[i:i + 3] for i in range(0, len(window), 3)]
    codon_indices = [i for i, codon in enumerate(codons) if get_synonymous(codon)]
    orig_aa = translate(window)
    
    # Optimize: prioritize preferred enzymes and limit search for large sequences
    preferred_enzymes = ["SalI", "EagI", "RsrII", "KpnI", "MluI", "SbfI", "NcoI", "DpnI"]
    preferred_set = set(preferred_enzymes)
    priority_enzymes = [e for e in enzymes if str(e) in preferred_set]
    other_enzymes = [e for e in enzymes if str(e) not in preferred_set]
    
    # Use all available enzymes for comprehensive search
    enzyme_list = priority_enzymes + other_enzymes
    
    result_count = 0
    max_results = 500  # Allow more results

    for k in range(1, min(max_changes + 1, len(codon_indices) + 1)):
        if result_count >= max_results:
            break
            
        for combo in itertools.combinations(codon_indices, k):
            if result_count >= max_results:
                break
                
            syn_options = [get_synonymous(codons[i]) for i in combo]
            for replacements in itertools.product(*syn_options):
                if result_count >= max_results:
                    break
                    
                new_codons = codons[:]
                for idx, new_codon in zip(combo, replacements):
                    new_codons[idx] = new_codon
                mutated = ''.join(new_codons)
                if translate(mutated) != orig_aa:
                    continue
                    
                for enzyme in enzyme_list:
                    if result_count >= max_results:
                        break
                        
                    cut = site_in_window(mutated, enzyme, cut_pos - start, tolerance)
                    if cut is not None:
                        # Determine removed sequence (difference from original)
                        removed_bases = ''.join([o for o, m in zip(window, mutated) if o != m])
                        side = "5'" if mutated.find(str(enzyme.site)) < len(mutated) // 2 else "3'"

                        results.append({
                            'enzyme': enzyme,
                            'new_cut': start + cut,
                            'orig_window': window,
                            'mutated': mutated,
                            'aa': translate(mutated),
                            'window_start': start,
                            'window_end': end,
                            'codon_start': codon_start,
                            'removed_bases': removed_bases,
                            'removed_side': side
                        })
                        result_count += 1
    return results

# === END EXACT COPY ===

# Helper functions for Flask integration
def validate_dna_sequence(dna):
    """Validate DNA sequence contains only ATCG"""
    if not dna:
        return False, "DNA sequence is required"
    
    # Allow only A, T, C, G (case insensitive)
    valid_chars = set('ATCG')
    if not all(c in valid_chars for c in dna.upper()):
        return False, "DNA sequence must contain only A, T, C, G characters"
    
    return True, "Valid DNA sequence"

def filter_enzymes_not_in_sequence(dna):
    """Filter enzymes that are not already present in the sequence"""
    return [e for e in CommOnly if str(e.site) not in dna]

def get_preferred_enzymes():
    """Get list of preferred enzymes"""
    return ["SalI", "EagI", "RsrII", "KpnI", "MluI", "SbfI", "NcoI", "DpnI"]

def rank_results_by_preference(results):
    """Rank results with preferred enzymes first"""
    preferred_enzymes = get_preferred_enzymes()
    preferred_set = set(preferred_enzymes)
    
    # Convert to DataFrame and add preference ranking
    df = pd.DataFrame(results)
    df['is_preferred'] = df['enzyme'].astype(str).isin(list(preferred_set))
    df['enzyme_str'] = df['enzyme'].astype(str)
    
    # Sort by preference, then alphabetically
    df = df.sort_values(['is_preferred', 'enzyme_str'], ascending=[False, True])
    
    matched_preferred = list(set(df[df['is_preferred']]['enzyme_str'].tolist()))
    
    return df, matched_preferred

# Build enzyme dict for primer design
neb_enzymes = {}
for enz in AllEnzymes:
    if enz.site:
        neb_enzymes[enz.__name__] = enz.site.upper()

def calculate_tm(primer, target=None):
    """Simple melting temperature calculation"""
    gc_count = primer.count('G') + primer.count('C')
    at_count = primer.count('A') + primer.count('T')
    
    if len(primer) < 14:
        tm = (at_count * 2) + (gc_count * 4)
    else:
        tm = 64.9 + 41 * (gc_count - 16.4) / len(primer)
    
    return round(tm, 1)

def generate_primers(sequence, tm_target=60.0, max_length=30):
    """Generate forward and reverse primers"""
    primers = []
    
    # Forward primers
    for length in range(18, max_length + 1):
        if length <= len(sequence):
            primer = sequence[:length]
            tm = calculate_tm(primer)
            primers.append({
                'direction': 'Forward',
                'sequence': primer,
                'length': length,
                'tm': tm,
                'gc_content': round((primer.count('G') + primer.count('C')) / length * 100, 1)
            })
    
    # Reverse primers (reverse complement of 3' end)
    for length in range(18, max_length + 1):
        if length <= len(sequence):
            end_seq = sequence[-length:]
            primer = str(Seq(end_seq).reverse_complement())
            tm = calculate_tm(primer)
            primers.append({
                'direction': 'Reverse',
                'sequence': primer,
                'length': length,
                'tm': tm,
                'gc_content': round((primer.count('G') + primer.count('C')) / length * 100, 1)
            })
    
    return primers

# Flask routes
@app.route("/")
def home():
    """Home page redirects to silent mutations"""
    return render_template("silent_mutations.html")

@app.route("/silent-mutations", methods=["GET", "POST"])
def silent_mutations():
    """Silent mutation generator page"""
    if request.method == "POST":
        try:
            dna = request.form.get("dna", "").strip().upper().replace(" ", "").replace("\n", "").replace("\r", "")
            cut_pos = int(request.form.get("cut_pos", "1")) - 1  # Convert to 0-based
            tolerance = int(request.form.get("tolerance", 5))
            window_codons = int(request.form.get("window_codons", 10))
            max_changes = int(request.form.get("max_changes", 3))
            coding_start_pos = 0  # Use 0 for valid windows

            # Validate DNA sequence
            is_valid, message = validate_dna_sequence(dna)
            if not is_valid:
                flash(message, "error")
                return render_template("silent_mutations.html")

            if cut_pos < 0 or cut_pos >= len(dna):
                flash("Cut position is out of range.", "error")
                return render_template("silent_mutations.html")

            # Get enzymes not already present in sequence
            enzymes = filter_enzymes_not_in_sequence(dna)
            
            # Find silent mutations using EXACT USER CODE
            results = find_silent_sites(dna, cut_pos, tolerance, window_codons, enzymes, coding_start_pos, max_changes)
            
            # Rank results by preference
            if results:
                results_df, matched_preferred = rank_results_by_preference(results)
                results = results_df.to_dict('records')
                
                if matched_preferred:
                    flash(f"Found {len(matched_preferred)} preferred enzymes: {', '.join(matched_preferred)}", "success")
                else:
                    flash(f"Found {len(results)} mutations. No preferred enzymes found.", "info")
            else:
                flash("No valid silent mutations found. Try increasing tolerance or window size.", "warning")

            return render_template("silent_mutations.html", 
                                 results=results, 
                                 dna=dna,
                                 cut_pos=cut_pos+1,  # Convert back to 1-based for display
                                 tolerance=tolerance,
                                 window_codons=window_codons,
                                 max_changes=max_changes)

        except ValueError as e:
            flash(f"Invalid input: {str(e)}", "error")
        except Exception as e:
            flash(f"Error processing request: {str(e)}", "error")

    return render_template("silent_mutations.html")

@app.route("/export-csv")
def export_csv():
    """Export silent mutation results to CSV"""
    # Get results from session or re-run analysis
    # For simplicity, we'll expect the results to be passed as parameters
    # In a real application, you'd store results in session
    flash("CSV export functionality requires results to be generated first.", "info")
    return redirect(url_for("silent_mutations"))

@app.route("/primer-design", methods=["GET", "POST"])
def primer_design():
    """Primer design page"""
    if request.method == "POST":
        try:
            # Get form data
            dna_seq = request.form.get("dna_seq", "").strip().upper()
            aa_seq = request.form.get("aa_seq", "").strip().upper()
            insert_pos = request.form.get("insert_pos", "").strip()
            enzyme_name = request.form.get("enzyme", "").strip()
            tm_target = float(request.form.get("tm_target", 60))
            
            if not dna_seq:
                flash("DNA sequence is required.", "error")
                return render_template("primer_design.html", enzymes=list(neb_enzymes.keys()))
            
            # Validate DNA sequence
            is_valid, message = validate_dna_sequence(dna_seq)
            if not is_valid:
                flash(message, "error")
                return render_template("primer_design.html", enzymes=list(neb_enzymes.keys()))
            
            primers = []
            
            if enzyme_name and enzyme_name in neb_enzymes:
                # Enzyme insertion workflow
                enzyme_site = neb_enzymes[enzyme_name]
                
                if insert_pos:
                    try:
                        pos = int(insert_pos) - 1  # Convert to 0-based
                        if 0 <= pos <= len(dna_seq):
                            # Insert enzyme site at position
                            modified_seq = dna_seq[:pos] + enzyme_site + dna_seq[pos:]
                            primers = generate_primers(modified_seq, tm_target)
                            
                            flash(f"Generated primers for {enzyme_name} insertion at position {insert_pos}", "success")
                        else:
                            flash("Insert position is out of range.", "error")
                    except ValueError:
                        flash("Invalid insert position.", "error")
                else:
                    # Generate primers for the sequence with enzyme site at the end
                    modified_seq = dna_seq + enzyme_site
                    primers = generate_primers(modified_seq, tm_target)
                    flash(f"Generated primers with {enzyme_name} site at the end", "success")
            
            elif aa_seq:
                # Amino acid insertion workflow
                aa_dna = ""
                for aa in aa_seq:
                    if aa in SYNONYMOUS:
                        # Use the first codon for each amino acid
                        aa_dna += SYNONYMOUS[aa][0]
                    else:
                        flash(f"Invalid amino acid: {aa}", "error")
                        return render_template("primer_design.html", enzymes=list(neb_enzymes.keys()))
                
                if insert_pos:
                    try:
                        pos = int(insert_pos) - 1  # Convert to 0-based
                        if 0 <= pos <= len(dna_seq):
                            # Insert amino acid sequence at position
                            modified_seq = dna_seq[:pos] + aa_dna + dna_seq[pos:]
                            primers = generate_primers(modified_seq, tm_target)
                            
                            flash(f"Generated primers for amino acid insertion at position {insert_pos}", "success")
                        else:
                            flash("Insert position is out of range.", "error")
                    except ValueError:
                        flash("Invalid insert position.", "error")
                else:
                    # Generate primers for the sequence with amino acids at the end
                    modified_seq = dna_seq + aa_dna
                    primers = generate_primers(modified_seq, tm_target)
                    flash(f"Generated primers with amino acid sequence at the end", "success")
            
            else:
                # Just generate primers for the original sequence
                primers = generate_primers(dna_seq, tm_target)
                flash("Generated primers for the original sequence", "success")
            
            # Filter primers close to target Tm
            if primers:
                primers = [p for p in primers if abs(p['tm'] - tm_target) <= 10]  # Within 10°C
                primers = sorted(primers, key=lambda x: abs(x['tm'] - tm_target))  # Sort by closeness to target
            
            return render_template("primer_design.html", 
                                 primers=primers,
                                 enzymes=list(neb_enzymes.keys()),
                                 dna_seq=dna_seq,
                                 aa_seq=aa_seq,
                                 insert_pos=insert_pos,
                                 enzyme=enzyme_name,
                                 tm_target=tm_target)
                                 
        except Exception as e:
            flash(f"Error: {str(e)}", "error")
    
    return render_template("primer_design.html", enzymes=list(neb_enzymes.keys()))

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)