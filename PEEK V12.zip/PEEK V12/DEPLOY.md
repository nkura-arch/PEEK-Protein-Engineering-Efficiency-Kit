# Deploying PEEK V12

The included Dockerfile and Fly configuration are unchanged from V10. The
Dockerfile uses Python 3.11 and serves Flask through Gunicorn on port 8080.
The fly.toml configuration targets the existing peek-host application.

Before deploying, review the target app and provide SESSION_SECRET through the
host's secret configuration. Do not put a production secret in source files.

Read VALIDATION.txt for local test results and limits. Build and test the
production container before publishing. After deployment, check the tool pages,
a design submission, static assets and HTTPS on the production domain.

Browser inputs and result history are saved locally by the existing scripts.
The tools drawer starts closed on each page. Localhost previews do not
load the production GoatCounter analytics script.

This package does not itself deploy or change the live application.
