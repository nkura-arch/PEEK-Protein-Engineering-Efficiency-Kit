PEEK V12 / Protein Engineering Efficiency Kit

V12 preserves the original scientific tools and calculations with the redesigned
dark-blue interface. It adds a sliding tools sidebar and removes the motion
status button. Device reduced-motion preferences remain respected.

The tools drawer starts closed. Click the larger Show tools button to slide it
open, then Hide tools to close it. Mouse movement, outside clicks and focus
changes leave the drawer open. Its close button and Escape also dismiss it.
Touch users can tap the same controls. Forms never shift or reset.

LOCAL SETUP
Create a Python environment, install requirements.txt and run python run_preview.py.
The existing launcher serves http://127.0.0.1:5000. The separately configured
preview on the development computer runs on port 5012.

FRONTEND STRUCTURE
templates/base.html          Shared navigation, page heading and asset links
static/css/workspace.css      Interface, forms, typography and responsive styles
static/css/navigation.css     Collapsible navigation layout and controls
static/css/motion.css         Decorative motion and interaction feedback
static/js/navigation.js       Button-controlled drawer with keyboard and touch access
static/js/motion.js           Reduced-motion handling and presentation feedback
static/dna-glass.webp         Transparent glass DNA illustration

The original tool scripts, static/js/main.js, Python modules and requirements
are preserved. Sequence-rendering geometry remains in the original templates.
No frontend build step or new runtime dependency is required.

SOURCE CLEANUP
Removed unused sequence-preview styling, inactive decoration, unused fonts and
older artwork. Consolidated added interface styles and removed superseded
declarations while preserving cascade order. New frontend files use consistent
formatting and descriptive names without version-specific classes.

See VALIDATION.txt for release checks and limits. V11 remains a separate local
release. This package has not been deployed to the production website.
