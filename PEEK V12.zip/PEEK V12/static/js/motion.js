// Optional interaction polish; never delays, cancels or changes a form request.
const root = document.body;
const hero = document.querySelector('.workspace-hero');
const art = document.querySelector('.hero-art');
const ambient = document.querySelector('.ambient-background');
const reduced = matchMedia('(prefers-reduced-motion: reduce)');
let preference = true;
try {
  preference = localStorage.getItem('peek:motion') !== 'off';
} catch (_) {
  /* private storage */
}
let enabled = false;
let frame = 0;
const animations = new WeakMap();
const feedback = new Set();

function parallax() {
  frame = 0;
  if (!enabled || document.hidden) return;
  // Layout is untouched: only decorative artwork moves, at most 20 CSS pixels.
  const box = hero.getBoundingClientRect();
  const amount = Math.min(1, Math.max(0, -box.top / Math.max(1, box.height)));
  art.style.setProperty('--hero-parallax', (amount * 20).toFixed(2) + 'px');
  ambient.style.setProperty(
    '--ambient-parallax',
    (-Math.min(scrollY * 0.025, 18)).toFixed(2) + 'px',
  );
}
function requestParallax() {
  if (enabled && !frame && !document.hidden)
    frame = requestAnimationFrame(parallax);
}
function updateMotion() {
  enabled = preference && !reduced.matches;
  root.dataset.motion = enabled ? 'on' : 'off';
  if (enabled) {
    requestParallax();
  } else {
    feedback.forEach((animation) => animation.cancel());
    cancelAnimationFrame(frame);
    frame = 0;
    art.style.removeProperty('--hero-parallax');
    ambient.style.removeProperty('--ambient-parallax');
  }
}
reduced.addEventListener('change', updateMotion);
window.addEventListener('scroll', requestParallax, { passive: true });
window.addEventListener('resize', requestParallax, { passive: true });
document.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    cancelAnimationFrame(frame);
    frame = 0;
  } else requestParallax();
});

// Short, interruptible feedback on actual selections. Keyboard users get it too.
document.addEventListener('change', (event) => {
  if (!enabled) return;
  const input = event.target;
  const target = input.matches('input[type=radio]')
    ? input.closest('.form-check')?.querySelector('.mode-option')
    : input.matches('select')
      ? input
      : null;
  if (!target?.animate) return;
  animations.get(target)?.cancel();
  const animation = target.animate(
    [
      { boxShadow: '0 0 0 0 rgba(146,206,248,.3)' },
      { boxShadow: '0 0 0 4px rgba(146,206,248,.12)', offset: 0.4 },
      { boxShadow: '0 0 0 0 rgba(146,206,248,0)' },
    ],
    { duration: 260, easing: 'ease-out' },
  );
  animations.set(target, animation);
  feedback.add(animation);
  animation.addEventListener('finish', () => feedback.delete(animation), {
    once: true,
  });
  animation.addEventListener('cancel', () => feedback.delete(animation), {
    once: true,
  });
});
window.addEventListener('pagehide', () => {
  cancelAnimationFrame(frame);
  frame = 0;
  feedback.forEach((animation) => animation.cancel());
});
window.addEventListener('pageshow', requestParallax);
updateMotion();
