(() => {
  const root = document.documentElement;
  root.dataset.navigationOpen = 'false';

  document.addEventListener('DOMContentLoaded', () => {
    const sidebar = document.getElementById('workspaceNavigation');
    const toggle = document.getElementById('navigationToggle');
    const close = document.getElementById('navigationClose');
    if (!sidebar || !toggle || !close) return;

    const label = toggle.querySelector('.navigation-label');
    let open = false;

    function setOpen(next) {
      open = next;
      sidebar.inert = !open;
      sidebar.setAttribute('aria-hidden', String(!open));
      root.dataset.navigationOpen = String(open);
      toggle.setAttribute('aria-expanded', String(open));
      label.textContent = open ? 'Hide tools' : 'Show tools';
    }

    function dismiss() {
      if (sidebar.contains(document.activeElement)) {
        toggle.focus({ preventScroll: true });
      }
      setOpen(false);
    }

    // Tap and keyboard access use the same drawer, without requiring hover.
    toggle.addEventListener('click', (event) => {
      if (open) dismiss();
      else {
        setOpen(true);
        if (event.detail === 0) sidebar.querySelector('.tool-link')?.focus();
      }
    });
    close.addEventListener('click', dismiss);
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && open) {
        event.preventDefault();
        dismiss();
      }
    });
    toggle.hidden = false;
    close.hidden = false;
    setOpen(false);
  });
})();
