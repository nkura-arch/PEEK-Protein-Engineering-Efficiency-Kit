# Deploying PEEK — first-time checklist

## What was already hardened in this copy
- Debug mode turned OFF in app.py (prevents the biggest Flask security hole).
- Logging lowered from DEBUG to INFO.
- Procfile added so the host runs it with gunicorn (a real production server).
- pyproject.toml trimmed to only the packages the app actually uses.
- .gitignore added so junk files aren't uploaded.

## Steps
1. Put this folder in a PRIVATE GitHub repository.
2. On Render (render.com): New -> Web Service -> connect the repo.
   - Render auto-detects Python and installs from requirements.txt.
   - It reads the Procfile for the start command. Nothing to type.
3. In the host's Environment / Variables section, add:
   - Key:   SESSION_SECRET
   - Value: (paste the long random string Claude gave you)
4. Deploy. You'll get a free URL like peek-xxxx.onrender.com. Test it.
5. Custom domain: buy one (Namecheap / Cloudflare / Porkbun), then in the
   host dashboard add a Custom Domain and paste the DNS record it shows you
   into your registrar. HTTPS certificate is issued automatically.

## Notes
- If the app runs out of memory on a small/free instance, change
  "--workers 2" to "--workers 1" in the Procfile.
- The heavy science library (ViennaRNA / "import RNA") normally installs fine
  from requirements.txt. If the build fails, that's the likely spot to look.
- The "Download App" nav button lets ANY visitor download your full source.
  The "V7 Validation Report" button needs the .docx file added to this folder
  or it will show "Report not found." See Claude's message about both.
