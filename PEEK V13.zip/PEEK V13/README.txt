PEEK V13 / Protein Engineering Efficiency Kit

Home and tools
/ and /home render a dedicated Home page with six links to existing capabilities:
silent mutations, enzyme insertion, amino acid/DNA insertion, indels and
amplification, insertion verification and sequence visualization. Home has no
scientific input form. Each tool page opens with a compact heading.
Home's primer links select an existing mode through a validated URL parameter
without clearing the shared DNA sequence. The original forms and calculations
handle every design submission.

Visuals
The current navy/cobalt palette is retained. A locally served, microscopy-inspired
molecular illustration replaces the mountains and floating DNA. Fine stippling,
dithering and a grain overlay provide the textured effect. This is decorative
art, not experimental data. Inter serves labels, controls and body text; Playfair Display is shared by page,
section, result, modal and library headings. A shared typography stylesheet
keeps weights, spacing and readable sizes consistent across the site. Controls stay sharp with restrained borders and readable text.
The header artwork is static. Decorative text motion respects reduced motion.

Navigation
The Tools button is outside the sticky header's stacking context. It works before
and after scrolling. Its drawer matches the page background. Use the button,
close control or Escape to close; mouse movement and outside clicks leave it open.
The desktop tab has a reserved rail so it cannot overlap workspace text. Phones
and tablets have a header control. Home and every tool are accessible in the drawer.
PEEK preprint links to https://doi.org/10.64898/2026.10.29.762953.

LOCAL SETUP
Create a Python environment, install requirements.txt and run python run_preview.py.
The supplied launcher serves http://127.0.0.1:5000. The separate development
preview on this computer runs at http://localhost:5013/home.

IMPLEMENTATION
templates/home.html           Dedicated Home and tool directory
templates/base.html           Shared navigation, headings and footer
static/css/reference.css      Home composition and responsive layouts
static/css/surfaces.css       Shared palette and control treatments
static/css/typography.css     Site-wide heading and interface type hierarchy
static/css/navigation.css     Drawer and reserved rail
static/js/reference.js        Presentation and validated primer entry modes
static/js/navigation.js       Explicit navigation controls
static/reference/             Local molecular artwork and fonts with licenses

Only the index and home route functions in app.py changed to render home.html.
All scientific code in that file remains identical to the baseline. The other
seven Python files, original main.js, dependencies and deployment configuration
are unchanged. Inline scientific/workflow scripts differ only in punctuation.
No new runtime dependencies or frontend build step are required.

V12 source/ZIP and earlier V13 snapshots are preserved. This version has not been
pushed or deployed. See VALIDATION.txt for evidence and limitations.
