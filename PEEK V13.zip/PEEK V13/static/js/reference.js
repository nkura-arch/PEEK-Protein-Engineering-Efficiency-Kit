// Presentation only. The scientific forms and their state remain independent.
const body = document.body;
const hero = document.querySelector('.reference-hero');
const heroContent = document.querySelector('.reference-hero-content');
const reduced = matchMedia('(prefers-reduced-motion: reduce)');
const reveals = [...document.querySelectorAll('.reference-reveal')];
let frame = 0;
let observer;
let heroVisible = true;
let motionAllowed = true;
try {
  motionAllowed = localStorage.getItem('peek:motion') !== 'off';
} catch (_) {
  /* Storage is optional. */
}

function renderScroll() {
  frame = 0;
  body.dataset.navScrolled = String(scrollY > 50);
  if (body.dataset.motion !== 'on' || document.hidden) return;
  if (hero && heroVisible) {
    const offset = Math.min(
      70,
      Math.max(0, -hero.getBoundingClientRect().top * 0.15),
    );
    heroContent.style.setProperty('--reference-hero-offset', `${offset}px`);
  }
}
function requestScroll() {
  if (!frame && !document.hidden) frame = requestAnimationFrame(renderScroll);
}
function updateMotion() {
  const enabled = motionAllowed && !reduced.matches;
  body.dataset.motion = enabled ? 'on' : 'off';
  body.classList.toggle('reference-motion', enabled);
  observer?.disconnect();
  if (enabled && 'IntersectionObserver' in window) {
    observer = new IntersectionObserver(
      (entries) =>
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          entry.target.removeAttribute('data-reveal');
          observer.unobserve(entry.target);
        }),
      { threshold: 0.08 },
    );
    reveals.forEach((element) => {
      if (element.getBoundingClientRect().top > innerHeight)
        element.dataset.reveal = 'pending';
      observer.observe(element);
    });
  } else {
    reveals.forEach((element) => element.removeAttribute('data-reveal'));
    heroContent?.style.removeProperty('--reference-hero-offset');
  }
  requestScroll();
}
const visibility = new IntersectionObserver(
  ([entry]) => {
    heroVisible = entry.isIntersecting;
    body.dataset.referencePaused = String(document.hidden || !heroVisible);
  },
  { threshold: 0 },
);
if (hero) visibility.observe(hero);
window.addEventListener('scroll', requestScroll, { passive: true });
window.addEventListener('resize', requestScroll, { passive: true });
reduced.addEventListener('change', updateMotion);
document.addEventListener('visibilitychange', () => {
  body.dataset.referencePaused = String(document.hidden || !heroVisible);
  if (document.hidden) {
    cancelAnimationFrame(frame);
    frame = 0;
  } else {
    requestScroll();
  }
});
window.addEventListener('pagehide', () => {
  cancelAnimationFrame(frame);
  observer?.disconnect();
  visibility.disconnect();
});
window.addEventListener('pageshow', () => {
  updateMotion();
  if (hero) visibility.observe(hero);
});
updateMotion();
// Return submissions to their workspace, keeping repeated use direct.
if (window.PEEK_DID_POST && !location.hash) {
  requestAnimationFrame(() =>
    document
      .getElementById('workspace')
      .scrollIntoView({ behavior: 'instant' }),
  );
}

function applyToolEntry() {
  if (window.PEEK_DID_POST || document.body.dataset.page !== 'primer_design')
    return;
  const mode = new URLSearchParams(location.search).get('mode');
  if (!['enzyme', 'insert', 'amplify', 'verify'].includes(mode)) return;
  const radio = document.getElementById(`${mode}_mode`);
  if (radio) {
    radio.checked = true;
    radio.dispatchEvent(new Event('change', { bubbles: true }));
  }
}
if (document.readyState === 'loading')
  document.addEventListener('DOMContentLoaded', applyToolEntry, { once: true });
else applyToolEntry();
