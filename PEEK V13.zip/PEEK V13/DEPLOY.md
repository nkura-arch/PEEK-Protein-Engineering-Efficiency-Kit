# Uploading PEEK V13

Extract `PEEK V13.zip`. Upload or copy the contents of the `PEEK V13` folder to
the existing application's project root. `app.py`, `requirements.txt`, `Dockerfile`,
`fly.toml`, `templates/` and `static/` must remain together at that root.
Include every file in `static/reference/`, including the local fonts and artwork.
Do not upload the ZIP itself as an application file or nest the extracted folder
inside another app folder.

The included Dockerfile and Fly configuration match the original project.
The Dockerfile uses Python 3.11 and serves Flask through Gunicorn on port 8080.
`fly.toml` targets the existing `peek-host` application. Its hostname and the
existing domain/analytics configuration are retained.

Keep the existing `SESSION_SECRET` configured in the host's secrets. It is not
included in this ZIP. Keep the host's other existing environment settings.

For Fly, deploy from the extracted application root using `fly deploy` after
reviewing the target app. This package does not perform deployment automatically.
After deployment, check `/`, `/home`, `/silent-mutations`, `/primer-design`,
`/sequence-visualizer`, `/about`, a design submission and the local fonts/artwork
on the production HTTPS domain.

Read `VALIDATION.txt` for the final local checks. Docker was unavailable locally,
so the production container and live hosting environment remain unverified.

The tools drawer starts closed on each page. Existing scripts retain browser
inputs and results between tool visits. Localhost does not load GoatCounter.
