from app import app

if __name__ == "__main__":
    # Prefer waitress: it supports HTTP keep-alive, so switching between tabs
    # doesn't pay a per-navigation connection stall (the Werkzeug dev server
    # does not keep connections alive and feels noticeably slower).
    try:
        from waitress import serve
        print("Serving PEEK on http://127.0.0.1:5000  (waitress)")
        serve(app, host="0.0.0.0", port=5000, threads=8, channel_timeout=120)
    except ImportError:
        app.run(host="0.0.0.0", port=5000, debug=True, threaded=True)
